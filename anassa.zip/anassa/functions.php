<?php
/**
 * Anassa Holidays — το React site μέσα σε θέμα WordPress.
 *
 * Πώς δουλεύει, σε μία παράγραφο: το WordPress κρατά το περιεχόμενο που αλλάζει
 * ο πελάτης (εκδρομές, άρθρα) και τα αιτήματα των φορμών. Σε κάθε σελίδα του
 * front-end σερβίρει το ίδιο build του React (`app/index.html`), και γράφει μέσα
 * του ένα `window.__ANASSA__` με τις εκδρομές και τα άρθρα. Το React τα διαβάζει
 * σύγχρονα (`src/lib/wp.ts`), οπότε η εμφάνιση είναι ακριβώς το site του repo.
 *
 * Τεκμηρίωση και οδηγίες εγκατάστασης: `showcase/anassa/wordpress/README.md`.
 */

defined( 'ABSPATH' ) || exit;

define( 'ANASSA_DIR', __DIR__ );
define( 'ANASSA_APP_DIR', __DIR__ . '/app' );

require ANASSA_DIR . '/inc/helpers.php';
require ANASSA_DIR . '/inc/trips.php';
require ANASSA_DIR . '/inc/blog.php';
require ANASSA_DIR . '/inc/enquiry.php';
require ANASSA_DIR . '/inc/seo.php';
require ANASSA_DIR . '/inc/announcement.php';
require ANASSA_DIR . '/inc/nav.php';
require ANASSA_DIR . '/inc/pages.php';
require ANASSA_DIR . '/inc/texts.php';
require ANASSA_DIR . '/inc/images.php';
require ANASSA_DIR . '/inc/app.php';
require ANASSA_DIR . '/inc/seed.php';

add_action(
	'after_setup_theme',
	static function () {
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'title-tag' );
	}
);
