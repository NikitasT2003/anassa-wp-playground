<?php
/**
 * Δεν φτάνει ποτέ εδώ: το `inc/app.php` σερβίρει το front-end στο
 * `template_redirect`. Το αρχείο υπάρχει γιατί το WordPress δεν δέχεται θέμα
 * χωρίς `index.php`.
 */

defined( 'ABSPATH' ) || exit;

anassa_render_app();
