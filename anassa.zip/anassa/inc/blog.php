<?php
/**
 * Άρθρα: τα κανονικά «Άρθρα» του WordPress, με τρία επιπλέον πεδία (φωτογραφία
 * κεφαλίδας, σχετικές εκδρομές, τίτλος για Google) και τη μετατροπή στο σχήμα
 * `WpPost` του `src/lib/wp.ts`.
 *
 * ΤΑ ΤΡΙΑ ΑΡΧΙΚΑ ΑΡΘΡΑ μένουν .mdx μέσα στο build (έχουν Tabs, Accordions,
 * Steps, γκαλερί που ο επεξεργαστής δεν ξαναφτιάχνει). Εδώ ζουν τα νέα.
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'add_meta_boxes',
	static function () {
		add_meta_box( 'anassa_post_details', 'Στοιχεία άρθρου για το site', 'anassa_post_metabox', 'post', 'side', 'high' );
	}
);

function anassa_post_metabox( WP_Post $post ): void {
	wp_nonce_field( 'anassa_post_save', 'anassa_post_nonce' );
	$hero    = (string) get_post_meta( $post->ID, '_anassa_heroTrip', true );
	$related = get_post_meta( $post->ID, '_anassa_relatedTrips', true );
	$related = is_array( $related ) ? $related : array();
	$seo     = (string) get_post_meta( $post->ID, '_anassa_seoTitle', true );
	$trips   = anassa_trip_posts();
	?>
	<p>
		<label for="anassa_heroTrip"><strong>Φωτογραφία κεφαλίδας από την εκδρομή</strong></label><br>
		<select id="anassa_heroTrip" name="anassa_post[heroTrip]" style="width:100%">
			<?php foreach ( $trips as $trip ) : ?>
				<option value="<?php echo esc_attr( urldecode( $trip->post_name ) ); ?>" <?php selected( $hero, urldecode( $trip->post_name ) ); ?>><?php echo esc_html( get_the_title( $trip ) ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<p><strong>Σχετικές εκδρομές</strong><br>
		<?php foreach ( $trips as $trip ) : $slug = urldecode( $trip->post_name ); ?>
			<label style="display:block"><input type="checkbox" name="anassa_post[relatedTrips][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, $related, true ) ); ?>> <?php echo esc_html( get_the_title( $trip ) ); ?></label>
		<?php endforeach; ?>
	</p>
	<p>
		<label for="anassa_seoTitle"><strong>Τίτλος για τη Google</strong> (προαιρετικό)</label><br>
		<input type="text" id="anassa_seoTitle" name="anassa_post[seoTitle]" value="<?php echo esc_attr( $seo ); ?>" style="width:100%">
	</p>
	<p class="description">Η «Περίληψη» του άρθρου (κουτί παρακάτω) γίνεται η περιγραφή στη Google και στο ευρετήριο του blog. Γράψτε το πολύ δύο γραμμές.</p>
	<?php
}

add_action(
	'save_post_post',
	static function ( int $post_id ) {
		if ( ! isset( $_POST['anassa_post_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['anassa_post_nonce'] ), 'anassa_post_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$input = isset( $_POST['anassa_post'] ) && is_array( $_POST['anassa_post'] ) ? wp_unslash( $_POST['anassa_post'] ) : array();
		update_post_meta( $post_id, '_anassa_heroTrip', sanitize_title( (string) ( $input['heroTrip'] ?? '' ) ) );
		$related = isset( $input['relatedTrips'] ) && is_array( $input['relatedTrips'] ) ? array_map( 'sanitize_title', $input['relatedTrips'] ) : array();
		update_post_meta( $post_id, '_anassa_relatedTrips', array_values( $related ) );
		update_post_meta( $post_id, '_anassa_seoTitle', sanitize_text_field( (string) ( $input['seoTitle'] ?? '' ) ) );
	}
);

/**
 * Ένα άρθρο στο σχήμα `WpPost`.
 *
 * @return array<string, mixed>
 */
function anassa_post_payload( WP_Post $post, string $fallback_hero ): array {
	$tags = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
	$hero = (string) get_post_meta( $post->ID, '_anassa_heroTrip', true );

	/* Το `the_content` τρέχει τα φίλτρα του WordPress (παράγραφοι, blocks). Τα
	   shortcodes και τα embeds δεν έχουν θέση εδώ: το React δέχεται μόνο καθαρό
	   HTML κειμένου (`src/components/blog/WpContent.tsx`). */
	$html = apply_filters( 'the_content', $post->post_content );

	$payload = array(
		'slug'         => urldecode( $post->post_name ),
		'title'        => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
		'description'  => wp_strip_all_tags( get_the_excerpt( $post ) ),
		'date'         => get_the_date( 'Y-m-d', $post ),
		'tags'         => array_values( $tags ),
		'heroTrip'     => '' !== $hero ? $hero : $fallback_hero,
		'relatedTrips' => array_values( (array) ( get_post_meta( $post->ID, '_anassa_relatedTrips', true ) ?: array() ) ),
		'html'         => (string) $html,
	);
	$seo = (string) get_post_meta( $post->ID, '_anassa_seoTitle', true );
	if ( '' !== $seo ) {
		$payload['seoTitle'] = $seo;
	}
	return $payload;
}

/**
 * @return array<int, array<string, mixed>>
 */
function anassa_blog_payload(): array {
	$trips    = anassa_trip_posts();
	$fallback = $trips ? urldecode( $trips[0]->post_name ) : '';
	$posts    = get_posts(
		array(
			'post_type'        => 'post',
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'suppress_filters' => false,
		)
	);
	return array_map( static fn( WP_Post $p ) => anassa_post_payload( $p, $fallback ), $posts );
}

/* Ένα άρθρο με slug που ήδη υπάρχει ως .mdx στο build δεν θα φανεί: νικά το
   .mdx. Το λέμε στην οθόνη επεξεργασίας αντί να χαθεί σιωπηλά. */
add_action(
	'admin_notices',
	static function () {
		$screen = get_current_screen();
		if ( ! $screen || 'post' !== $screen->post_type || 'post' !== $screen->base ) {
			return;
		}
		global $post;
		if ( ! $post || ! in_array( urldecode( $post->post_name ), anassa_manifest()['mdx'], true ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html( 'Αυτό το σύντομο όνομα (slug) το έχει ήδη ένα από τα αρχικά άρθρα του site. Θα εμφανίζεται εκείνο, όχι αυτό. Αλλάξτε το slug.' )
		);
	}
);
