<?php
/**
 * robots.txt, sitemap.xml και ο διακόπτης ευρετηρίασης.
 *
 * ΤΟ ΜΟΝΟ ΔΙΑΚΟΠΤΗ είναι το «Αποθάρρυνση μηχανών αναζήτησης» του WordPress
 * (Ρυθμίσεις → Ανάγνωση). Ανοιχτό = κλειστό site: noindex παντού, χωρίς
 * Sitemap στο robots.txt, και αποκλεισμός των bots που μαζεύουν corpus — η ίδια
 * πολιτική που έχει το `scripts/gen-sitemap.mjs` για `INDEXABLE = false`.
 * Στο go-live ο πελάτης (ή εμείς) το ξετσεκάρει και όλα ανοίγουν μαζί.
 */

defined( 'ABSPATH' ) || exit;

/* Το sitemap το γράφουμε εμείς, γιατί οι διαδρομές είναι του React. */
add_filter( 'wp_sitemaps_enabled', '__return_false' );

add_filter(
	'robots_txt',
	static function (): string {
		$origin = untrailingslashit( home_url() );
		$m      = anassa_manifest();
		$out    = "# Παράγεται από το θέμα Anassa. Ο διακόπτης είναι στο wp-admin → Ρυθμίσεις → Ανάγνωση.\n";
		$out   .= "User-agent: *\nAllow: /\n";
		foreach ( $m['excluded'] as $route ) {
			$out .= 'Disallow: ' . $route . "\n";
		}
		if ( get_option( 'blog_public' ) ) {
			return $out . "\nSitemap: " . $origin . "/sitemap.xml\n";
		}
		$bots = array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'anthropic-ai', 'PerplexityBot', 'Google-Extended', 'Applebot-Extended', 'meta-externalagent', 'Bytespider', 'CCBot' );
		$out .= "\n# Το site δεν είναι ακόμη δημοσιευμένο. Η σάρωση μένει ανοιχτή για να διαβάζεται το noindex·\n# τα bots συλλογής corpus δεν το διαβάζουν, οπότε αποκλείονται ρητά.\n";
		foreach ( $bots as $bot ) {
			$out .= "\nUser-agent: " . $bot . "\nDisallow: /\n";
		}
		return $out;
	}
);

add_action(
	'template_redirect',
	static function () {
		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH );
		if ( '/sitemap.xml' !== $path ) {
			return;
		}
		$origin = untrailingslashit( home_url() );
		$m      = anassa_manifest();
		$built  = $m['builtAt'] ? substr( (string) $m['builtAt'], 0, 10 ) : gmdate( 'Y-m-d' );
		$urls   = array();
		foreach ( $m['static'] as $route ) {
			$urls[] = array( $route, $built );
		}
		foreach ( anassa_boot_data()['trips'] as $trip ) {
			$urls[] = array( '/ekdromes/' . $trip['slug'], $built );
		}
		foreach ( $m['mdx'] as $slug ) {
			$urls[] = array( '/blog/' . $slug, $built );
		}
		foreach ( anassa_boot_data()['posts'] as $post ) {
			if ( ! in_array( $post['slug'], $m['mdx'], true ) ) {
				$urls[] = array( '/blog/' . $post['slug'], (string) $post['date'] );
			}
		}
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=utf-8' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $urls as $u ) {
			printf( "  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n  </url>\n", esc_html( $origin . ( '/' === $u[0] ? '/' : $u[0] ) ), esc_html( $u[1] ) );
		}
		echo "</urlset>\n";
		exit;
	},
	0
);
