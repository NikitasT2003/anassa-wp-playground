<?php
/**
 * Το μενού πλοήγησης (κεφαλίδα υπολογιστή και μενού κινητού, ΙΔΙΑ λίστα) αλλάζει
 * από το wp-admin, «Ρυθμίσεις → Μενού πλοήγησης»: στοιχεία με όνομα, αγγλικό
 * όνομα και σύνδεσμο, και ένα επίπεδο υπο-στοιχείων. Αν ένα στοιχείο έχει
 * υπο-στοιχεία γίνεται αναδυόμενο πλαίσιο· αλλιώς είναι απλός σύνδεσμος.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_NAV_OPTION = 'anassa_nav';

/** Η προεπιλογή: ό,τι έχει σήμερα το μενού, και το Travel Gift Voucher πίσω σε αυτό. */
function anassa_nav_defaults(): array {
	return array(
		array( 'label' => 'Εκδρομές', 'en' => '', 'url' => '/ekdromes', 'children' => array() ),
		array( 'label' => 'Σχεδιάζουμε Μαζί', 'en' => '', 'url' => '/sxediazoume-mazi', 'children' => array() ),
		array( 'label' => 'Travel Gift Voucher', 'en' => '', 'url' => '/taxidi-doro', 'children' => array() ),
		array(
			'label'    => 'Η Εταιρεία',
			'en'       => '',
			'url'      => '',
			'children' => array(
				array( 'label' => 'Η Ιστορία Μας', 'en' => '', 'url' => '/i-istoria-mas' ),
				array( 'label' => 'Επικοινωνία', 'en' => '', 'url' => '/epikoinonia' ),
				array( 'label' => 'Τρόποι Πληρωμής', 'en' => '', 'url' => '/tropoi-pliromis' ),
			),
		),
	);
}

function anassa_nav_get(): array {
	$saved = get_option( ANASSA_NAV_OPTION );
	return ( is_array( $saved ) && $saved ) ? $saved : anassa_nav_defaults();
}

/** ΜΟΝΟ εσωτερική διαδρομή του site («/ekdromes»): ο router του React δεν ανοίγει εξωτερικούς συνδέσμους. */
function anassa_nav_clean_url( string $url ): string {
	$url = trim( $url );
	if ( '' === $url ) {
		return '';
	}
	if ( 0 === strpos( $url, '/' ) && 0 !== strpos( $url, '//' ) ) {
		return '/' . ltrim( sanitize_text_field( $url ), '/' );
	}
	return '';
}

function anassa_nav_clean_item( $it, bool $allow_children ): ?array {
	if ( ! is_array( $it ) ) {
		return null;
	}
	$label = sanitize_text_field( (string) ( $it['label'] ?? '' ) );
	if ( '' === $label ) {
		return null;
	}
	$out = array(
		'label' => $label,
		'en'    => sanitize_text_field( (string) ( $it['en'] ?? '' ) ),
		'url'   => anassa_nav_clean_url( (string) ( $it['url'] ?? '' ) ),
	);
	if ( $allow_children ) {
		$kids = array();
		foreach ( (array) ( $it['children'] ?? array() ) as $child ) {
			$c = anassa_nav_clean_item( $child, false );
			if ( $c && '' !== $c['url'] ) {
				$kids[] = $c;
			}
		}
		$out['children'] = $kids;
		/* Στοιχείο χωρίς σύνδεσμο και χωρίς υπο-στοιχεία δεν οδηγεί πουθενά. */
		if ( '' === $out['url'] && ! $kids ) {
			return null;
		}
	} elseif ( '' === $out['url'] ) {
		return null;
	}
	return $out;
}

function anassa_nav_sanitize( $in ): array {
	/* Δύο μορφές εισόδου, γιατί το WordPress καλεί τον καθαριστή ΔΥΟ φορές στην
	   πρώτη αποθήκευση: την πρώτη με `{ json: "…" }` από τη φόρμα, τη δεύτερη με
	   τη λίστα που ήδη καθαρίστηκε. Η δεύτερη δεν πρέπει να χαθεί. */
	if ( is_array( $in ) && isset( $in['json'] ) ) {
		$raw = json_decode( (string) $in['json'], true );
	} elseif ( is_array( $in ) ) {
		$raw = $in;
	} else {
		$raw = is_string( $in ) ? json_decode( $in, true ) : null;
	}
	$items = array();
	foreach ( (array) $raw as $it ) {
		$c = anassa_nav_clean_item( $it, true );
		if ( $c ) {
			$items[] = $c;
		}
	}
	return $items ? $items : anassa_nav_defaults();
}

/** Ό,τι περνά στο React (πάντα λίστα· η προεπιλογή όταν δεν έχει αποθηκευτεί τίποτα). */
function anassa_nav_payload(): array {
	return anassa_nav_get();
}

add_action(
	'admin_init',
	static function () {
		register_setting(
			'anassa_nav_group',
			ANASSA_NAV_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => 'anassa_nav_sanitize',
				'default'           => anassa_nav_defaults(),
			)
		);
	}
);

add_action(
	'admin_menu',
	static function () {
		add_options_page( 'Μενού πλοήγησης', 'Μενού πλοήγησης', 'manage_options', 'anassa-nav', 'anassa_nav_page' );
	}
);

add_action( 'update_option_' . ANASSA_NAV_OPTION, 'anassa_flush_boot' );
add_action( 'add_option_' . ANASSA_NAV_OPTION, 'anassa_flush_boot' );

function anassa_nav_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$items = anassa_nav_get();
	?>
	<div class="wrap">
		<h1>Μενού πλοήγησης</h1>
		<p>Το μενού πάνω στο site (και στο κινητό). Προσθέστε, μετακινήστε ή διαγράψτε στοιχεία. Ένα στοιχείο με «υπο-στοιχεία» ανοίγει ως πλαίσιο· χωρίς, είναι απλός σύνδεσμος. Σύνδεσμος: σελίδα του site, π.χ. <code>/ekdromes</code>, <code>/taxidi-doro</code>, <code>/blog</code>. Το αγγλικό όνομα είναι προαιρετικό.</p>
		<form method="post" action="options.php" id="anassa-nav-form">
			<?php settings_fields( 'anassa_nav_group' ); ?>
			<input type="hidden" name="<?php echo esc_attr( ANASSA_NAV_OPTION ); ?>[json]" id="anassa-nav-json">
			<div id="anassa-nav-rows"></div>
			<p><button type="button" class="button" id="anassa-nav-add">+ Προσθήκη στοιχείου</button></p>
			<?php submit_button( 'Αποθήκευση' ); ?>
		</form>
	</div>
	<style>
		.anassa-nav-item{background:#fff;border:1px solid #c3c4c7;padding:12px;margin:0 0 12px;max-width:900px}
		.anassa-nav-row{display:grid;grid-template-columns:1.2fr 1.2fr 1.6fr auto;gap:8px;align-items:center}
		.anassa-nav-kids{margin:10px 0 0 28px;border-left:3px solid #dcdcde;padding-left:12px}
		.anassa-nav-kids .anassa-nav-row{margin:0 0 8px}
		.anassa-nav-row input{width:100%}
		.anassa-nav-head{font-size:12px;color:#646970}
	</style>
	<script>
	( function () {
		var data = <?php echo wp_json_encode( $items, JSON_UNESCAPED_UNICODE ); ?>;
		var box = document.getElementById( 'anassa-nav-rows' );
		function el( tag, attrs, kids ) {
			var e = document.createElement( tag );
			Object.keys( attrs || {} ).forEach( function ( k ) { if ( k === 'text' ) e.textContent = attrs[k]; else e.setAttribute( k, attrs[k] ); } );
			( kids || [] ).forEach( function ( c ) { e.appendChild( c ); } );
			return e;
		}
		function input( obj, key, ph ) {
			var i = el( 'input', { type: 'text', placeholder: ph } );
			i.value = obj[key] || '';
			i.addEventListener( 'input', function () { obj[key] = i.value; } );
			return i;
		}
		function btn( text, fn ) {
			var b = el( 'button', { type: 'button', 'class': 'button', text: text } );
			b.addEventListener( 'click', fn );
			return b;
		}
		function move( arr, i, d ) { var j = i + d; if ( j < 0 || j >= arr.length ) return; var t = arr[i]; arr[i] = arr[j]; arr[j] = t; render(); }
		function rowFor( arr, i, top ) {
			var it = arr[i];
			var tools = el( 'span', {}, [
				btn( '↑', function () { move( arr, i, -1 ); } ),
				btn( '↓', function () { move( arr, i, 1 ); } ),
				btn( '✕', function () { arr.splice( i, 1 ); render(); } )
			] );
			return el( 'div', { 'class': 'anassa-nav-row' }, [
				input( it, 'label', 'Όνομα' ),
				input( it, 'en', 'English name' ),
				input( it, 'url', top ? 'Σύνδεσμος (κενό αν έχει υπο-στοιχεία)' : 'Σύνδεσμος' ),
				tools
			] );
		}
		function render() {
			box.innerHTML = '';
			data.forEach( function ( it, i ) {
				it.children = it.children || [];
				var kids = el( 'div', { 'class': 'anassa-nav-kids' } );
				it.children.forEach( function ( c, ci ) { kids.appendChild( rowFor( it.children, ci, false ) ); } );
				kids.appendChild( btn( '+ Υπο-στοιχείο', function () { it.children.push( { label: '', en: '', url: '' } ); render(); } ) );
				box.appendChild( el( 'div', { 'class': 'anassa-nav-item' }, [ rowFor( data, i, true ), kids ] ) );
			} );
		}
		document.getElementById( 'anassa-nav-add' ).addEventListener( 'click', function () { data.push( { label: '', en: '', url: '', children: [] } ); render(); } );
		document.getElementById( 'anassa-nav-form' ).addEventListener( 'submit', function () {
			document.getElementById( 'anassa-nav-json' ).value = JSON.stringify( data );
		} );
		render();
	} )();
	</script>
	<?php
}
