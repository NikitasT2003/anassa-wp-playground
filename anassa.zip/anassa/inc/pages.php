<?php
/**
 * Τα κείμενα των σελίδων (Η Ιστορία Μας, Σχεδιάζουμε μαζί, Travel Gift Voucher,
 * Τρόποι πληρωμής κ.λπ.) ζουν στο wp-admin → «Σελίδες site», με τον κανονικό
 * επεξεργαστή του WordPress. Ο σύντομος σύνδεσμος (slug) κάθε σελίδας είναι το
 * κλειδί που διαβάζει το React· τα κλειδιά δηλώνονται εδώ, δεν επινοούνται από
 * τον πελάτη.
 *
 * Κάθε σελίδα έχει: τίτλο, υπότιτλο (προαιρετικό), κείμενο, και τα ίδια τρία
 * στα αγγλικά (προαιρετικά· αν μείνουν κενά, η αγγλική εκδοχή του site δείχνει
 * το ελληνικό κείμενο ή την ενσωματωμένη μετάφραση).
 *
 * ΑΡΧΙΚΟ ΠΕΡΙΕΧΟΜΕΝΟ: τα αρχεία `seed/pages/*.json`, μία φορά, ώστε ο πελάτης να
 * βρει τα σημερινά κείμενα έτοιμα για επεξεργασία και όχι κενές σελίδες.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_PAGE = 'anassa_page';

add_action(
	'init',
	static function () {
		register_post_type(
			ANASSA_PAGE,
			array(
				'labels'              => array(
					'name'          => 'Σελίδες site',
					'singular_name' => 'Σελίδα',
					'add_new_item'  => 'Νέα σελίδα',
					'edit_item'     => 'Επεξεργασία σελίδας',
					'all_items'     => 'Όλες οι σελίδες',
					'menu_name'     => 'Σελίδες site',
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_rest'        => true, // ο επεξεργαστής μπλοκ
				'menu_position'       => 21,
				'menu_icon'           => 'dashicons-media-text',
				'supports'            => array( 'title', 'editor', 'revisions' ),
				'exclude_from_search' => true,
				'has_archive'         => false,
				'rewrite'             => false,
				'capability_type'     => 'post',
			)
		);
	}
);

/* ── Πεδία: υπότιτλος και αγγλική εκδοχή ──────────────────────────────────── */

add_action(
	'add_meta_boxes',
	static function () {
		add_meta_box( 'anassa_page_sub', 'Υπότιτλος (κάτω από τον τίτλο, προαιρετικός)', 'anassa_page_sub_box', ANASSA_PAGE, 'normal', 'high' );
		add_meta_box( 'anassa_page_en', 'English version (optional)', 'anassa_page_en_box', ANASSA_PAGE, 'normal', 'default' );
		add_meta_box( 'anassa_page_key', 'Πού εμφανίζεται', 'anassa_page_key_box', ANASSA_PAGE, 'side', 'high' );
	}
);

function anassa_page_key_box( WP_Post $post ): void {
	$slug  = urldecode( $post->post_name );
	$known = anassa_page_routes();
	if ( isset( $known[ $slug ] ) ) {
		printf( '<p>Η σελίδα: <a href="%1$s" target="_blank" rel="noopener"><code>%1$s</code></a></p>', esc_url( home_url( $known[ $slug ] ) ) );
	} else {
		echo '<p>Αυτό το κείμενο δεν αντιστοιχεί σε σελίδα του site. Μην αλλάζετε τον «σύντομο σύνδεσμο (slug)» των αρχικών σελίδων: από αυτόν τις βρίσκει το site.</p>';
	}
}

/** Slug → διαδρομή του site. */
function anassa_page_routes(): array {
	return array(
		'i-istoria-mas'    => '/i-istoria-mas',
		'sxediazoume-mazi' => '/sxediazoume-mazi',
		'taxidi-doro'      => '/taxidi-doro',
		'tropoi-pliromis'  => '/tropoi-pliromis',
		'syllogoi'         => '/syllogoi',
		'epikoinonia'      => '/epikoinonia',
		'oroi-symmetoxis'  => '/oroi-symmetoxis',
		'politiki-aporritou' => '/politiki-aporritou',
	);
}

function anassa_page_sub_box( WP_Post $post ): void {
	wp_nonce_field( 'anassa_page_save', 'anassa_page_nonce' );
	printf(
		'<input type="text" name="anassa_pg[sub]" value="%s" class="large-text">',
		esc_attr( (string) get_post_meta( $post->ID, '_anassa_sub', true ) )
	);
}

function anassa_page_en_box( WP_Post $post ): void {
	printf(
		'<p><label><strong>Title</strong><br><input type="text" name="anassa_pg[en_title]" value="%s" class="large-text"></label></p>',
		esc_attr( (string) get_post_meta( $post->ID, '_anassa_en_title', true ) )
	);
	printf(
		'<p><label><strong>Subtitle</strong><br><input type="text" name="anassa_pg[en_sub]" value="%s" class="large-text"></label></p>',
		esc_attr( (string) get_post_meta( $post->ID, '_anassa_en_sub', true ) )
	);
	echo '<p><strong>Text</strong></p>';
	wp_editor(
		(string) get_post_meta( $post->ID, '_anassa_en_html', true ),
		'anassa_pg_en_html',
		array(
			'textarea_name' => 'anassa_pg[en_html]',
			'textarea_rows' => 12,
			'media_buttons' => false,
		)
	);
}

add_action(
	'save_post_' . ANASSA_PAGE,
	static function ( int $post_id ) {
		if ( ! isset( $_POST['anassa_page_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['anassa_page_nonce'] ), 'anassa_page_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$in = isset( $_POST['anassa_pg'] ) && is_array( $_POST['anassa_pg'] ) ? wp_unslash( $_POST['anassa_pg'] ) : array();
		update_post_meta( $post_id, '_anassa_sub', sanitize_text_field( (string) ( $in['sub'] ?? '' ) ) );
		update_post_meta( $post_id, '_anassa_en_title', sanitize_text_field( (string) ( $in['en_title'] ?? '' ) ) );
		update_post_meta( $post_id, '_anassa_en_sub', sanitize_text_field( (string) ( $in['en_sub'] ?? '' ) ) );
		update_post_meta( $post_id, '_anassa_en_html', wp_kses_post( (string) ( $in['en_html'] ?? '' ) ) );
	}
);

/* ── Τι περνά στο React ───────────────────────────────────────────────────── */

function anassa_page_html( string $html ): string {
	return trim( (string) apply_filters( 'the_content', $html ) );
}

/** `{ slug: { title, sub, html, en: { title, sub, html } } }`. Μόνο δημοσιευμένες. */
function anassa_pages_payload(): array {
	$posts = get_posts(
		array(
			'post_type'        => ANASSA_PAGE,
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'suppress_filters' => false,
		)
	);
	$out = array();
	foreach ( $posts as $p ) {
		$out[ urldecode( $p->post_name ) ] = array(
			'title' => get_the_title( $p ),
			'sub'   => (string) get_post_meta( $p->ID, '_anassa_sub', true ),
			'html'  => anassa_page_html( $p->post_content ),
			'en'    => array(
				'title' => (string) get_post_meta( $p->ID, '_anassa_en_title', true ),
				'sub'   => (string) get_post_meta( $p->ID, '_anassa_en_sub', true ),
				'html'  => anassa_page_html( (string) get_post_meta( $p->ID, '_anassa_en_html', true ) ),
			),
		);
	}
	return $out;
}

/* ── Αρχικό περιεχόμενο ───────────────────────────────────────────────────── */

/** Εισάγει ό,τι λείπει από τα `seed/pages/*.json`. Ό,τι υπάρχει ήδη δεν αγγίζεται. */
function anassa_seed_pages(): int {
	$created = 0;
	foreach ( (array) glob( ANASSA_DIR . '/seed/pages/*.json' ) as $file ) {
		$items = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $items ) ) {
			continue;
		}
		foreach ( $items as $it ) {
			if ( empty( $it['slug'] ) || empty( $it['title'] ) ) {
				continue;
			}
			$exists = get_posts(
				array(
					'post_type'      => ANASSA_PAGE,
					'post_status'    => 'any',
					'name'           => sanitize_title( $it['slug'] ),
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);
			if ( $exists ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'    => ANASSA_PAGE,
					'post_status'  => 'publish',
					'post_title'   => $it['title'],
					'post_name'    => sanitize_title( $it['slug'] ),
					'post_content' => (string) ( $it['html'] ?? '' ),
				),
				true
			);
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_anassa_sub', (string) ( $it['sub'] ?? '' ) );
			$en = is_array( $it['en'] ?? null ) ? $it['en'] : array();
			update_post_meta( $id, '_anassa_en_title', (string) ( $en['title'] ?? '' ) );
			update_post_meta( $id, '_anassa_en_sub', (string) ( $en['sub'] ?? '' ) );
			update_post_meta( $id, '_anassa_en_html', (string) ( $en['html'] ?? '' ) );
			++$created;
		}
	}
	if ( $created ) {
		anassa_flush_boot();
	}
	return $created;
}

/* Μία φορά στην πρώτη επίσκεψη διαχειριστή (ίδιος λόγος με το seed.php: το
   `after_switch_theme` δεν τρέχει αν το θέμα ήταν ήδη ενεργό). Το έκδοση-option
   επιτρέπει σε μελλοντικές εκδόσεις να προσθέσουν ΝΕΕΣ σελίδες χωρίς να
   πειράξουν όσες ο πελάτης έχει ήδη επεξεργαστεί. */
add_action(
	'admin_init',
	static function () {
		$have = (int) get_option( 'anassa_pages_seed_v', 0 );
		if ( $have >= 1 || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		anassa_seed_pages();
		update_option( 'anassa_pages_seed_v', 1 );
	}
);

add_action( 'after_switch_theme', 'anassa_seed_pages' );
