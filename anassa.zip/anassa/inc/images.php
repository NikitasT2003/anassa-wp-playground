<?php
/**
 * Οι φωτογραφίες φόντου του site, επεξεργάσιμες από το wp-admin:
 * «Ρυθμίσεις → Εικόνες φόντου».
 *
 * Ο πελάτης διαλέγει εικόνα από τη Βιβλιοθήκη Πολυμέσων του WordPress για κάθε
 * θέση παρακάτω, αποθηκεύει, και το site την δείχνει αμέσως. Αν δεν διαλέξει
 * τίποτα (ή πατήσει «Επαναφορά»), το site κρατά την προεπιλεγμένη φωτογραφία
 * του, που είναι φωτογραφία προορισμού από τον κατάλογο.
 *
 * ΔΥΟ ΕΙΔΗ ΘΕΣΕΩΝ:
 *  - μία εικόνα (`anassa_images_registry`)  → React: `window.__ANASSA__.images[κλειδί] = {url, srcset}`
 *  - καρουζέλ, πολλές εικόνες με σειρά (`anassa_galleries_registry`)
 *                                           → React: `window.__ANASSA__.galleries[κλειδί] = [{url, srcset}, …]`
 *
 * Τα μητρώα είναι ο κατάλογος των θέσεων. Τα κλειδιά ΠΡΕΠΕΙ να είναι ίδια με όσα
 * περνά το React (`<SiteBackground imageKey>` και `Custom.tsx`)· αν προσθέσετε ή
 * αλλάξετε ένα, αλλάξτε και το άλλο.
 *
 * Στο React περνούν ΜΟΝΟ οι θέσεις όπου ο πελάτης διάλεξε εικόνες. Ό,τι μένει
 * στην προεπιλογή δεν περνά.
 *
 * ΔΕΝ ΥΠΑΡΧΕΙ ΘΕΣΗ ΓΙΑ ΤΟ ΒΙΝΤΕΟ ΤΗΣ ΑΡΧΙΚΗΣ: είναι βίντεο, όχι εικόνα, και
 * αλλάζει με νέο build του θέματος.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_IMAGES_OPTION    = 'anassa_images';
const ANASSA_GALLERIES_OPTION = 'anassa_galleries';

/** key => [ ομάδα, ετικέτα, οδηγία για τον πελάτη ] */
function anassa_images_registry(): array {
	return array(
		'home.hero'  => array(
			'Αρχική',
			'Εισαγωγή «Εκδρομές με άποψη»: φωτογραφία φόντου',
			'Οριζόντια φωτογραφία τοπίου, τουλάχιστον 1920 px πλάτος. Προεπιλογή: φθινοπωρινό Πήλιο. Ο τίτλος γράφεται πάνω της, κάτω από σκούρο κάλυμμα.',
		),
		'home.about' => array(
			'Αρχική',
			'Ζώνη «Η ιστορία μας»: φωτογραφία φόντου',
			'Οριζόντια φωτογραφία, τουλάχιστον 1920 px πλάτος. Το κείμενο γράφεται πάνω της, κάτω από μπλε κάλυμμα.',
		),
		'gift.hero'  => array(
			'Ταξίδι Δώρο (Travel Gift Voucher)',
			'Κεφαλίδα: φωτογραφία φόντου',
			'Οριζόντια φωτογραφία τοπίου, τουλάχιστον 1920 px πλάτος. Ο τίτλος γράφεται πάνω της, κάτω από μπλε κάλυμμα.',
		),
	);
}

/** key => [ ομάδα, ετικέτα, οδηγία για τον πελάτη ] — θέσεις με ΠΟΛΛΕΣ εικόνες. */
function anassa_galleries_registry(): array {
	return array(
		'custom.slides' => array(
			'Σχεδιάζουμε Μαζί',
			'Κεφαλίδα: καρουζέλ φωτογραφιών φόντου',
			'Φωτογραφίες από διάφορα μέρη, οριζόντιες, τουλάχιστον 1920 px πλάτος. Εναλλάσσονται με τη σειρά που τις επιλέγετε. Ο τίτλος γράφεται πάνω τους, κάτω από μπλε κάλυμμα. Αν δεν διαλέξετε καμία, δείχνει τις προεπιλεγμένες φωτογραφίες προορισμών.',
		),
	);
}

function anassa_images_get(): array {
	$saved = get_option( ANASSA_IMAGES_OPTION );
	return is_array( $saved ) ? $saved : array();
}

function anassa_galleries_get(): array {
	$saved = get_option( ANASSA_GALLERIES_OPTION );
	return is_array( $saved ) ? $saved : array();
}

/** Μία εικόνα → { url, srcset }, ή null αν δεν υπάρχει πια στη Βιβλιοθήκη. */
function anassa_image_item( int $id ): ?array {
	$url = wp_get_attachment_image_url( $id, 'full' );
	if ( ! $url ) {
		return null;
	}
	$srcset = wp_get_attachment_image_srcset( $id, 'full' );
	return array(
		'url'    => $url,
		'srcset' => $srcset ? $srcset : '',
	);
}

/** Ό,τι περνά στο React: μόνο οι θέσεις με εικόνα που υπάρχει ακόμη στη Βιβλιοθήκη. */
function anassa_images_payload(): array {
	$saved = anassa_images_get();
	$out   = array();
	foreach ( array_keys( anassa_images_registry() ) as $key ) {
		$id = isset( $saved[ $key ] ) ? (int) $saved[ $key ] : 0;
		if ( $id <= 0 ) {
			continue;
		}
		$item = anassa_image_item( $id );
		if ( $item ) {
			$out[ $key ] = $item; // αν η εικόνα σβήστηκε, το site γυρνά στην προεπιλογή.
		}
	}
	return $out;
}

function anassa_galleries_payload(): array {
	$saved = anassa_galleries_get();
	$out   = array();
	foreach ( array_keys( anassa_galleries_registry() ) as $key ) {
		$ids   = isset( $saved[ $key ] ) && is_array( $saved[ $key ] ) ? $saved[ $key ] : array();
		$items = array();
		foreach ( $ids as $id ) {
			$item = anassa_image_item( (int) $id );
			if ( $item ) {
				$items[] = $item;
			}
		}
		if ( $items ) {
			$out[ $key ] = $items;
		}
	}
	return $out;
}

function anassa_images_sanitize( $in ): array {
	$in  = is_array( $in ) ? $in : array();
	$out = array();
	foreach ( array_keys( anassa_images_registry() ) as $key ) {
		$id = isset( $in[ $key ] ) ? absint( $in[ $key ] ) : 0;
		// Μόνο υπαρκτές εικόνες της Βιβλιοθήκης Πολυμέσων.
		if ( $id > 0 && wp_attachment_is_image( $id ) ) {
			$out[ $key ] = $id;
		}
	}
	return $out;
}

function anassa_galleries_sanitize( $in ): array {
	$in  = is_array( $in ) ? $in : array();
	$out = array();
	foreach ( array_keys( anassa_galleries_registry() ) as $key ) {
		$raw = isset( $in[ $key ] ) ? (string) wp_unslash( $in[ $key ] ) : '';
		$ids = array();
		foreach ( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) as $id ) {
			if ( wp_attachment_is_image( $id ) ) {
				$ids[] = $id;
			}
		}
		if ( $ids ) {
			$out[ $key ] = $ids;
		}
	}
	return $out;
}

add_action(
	'admin_init',
	static function () {
		register_setting(
			'anassa_images_group',
			ANASSA_IMAGES_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => 'anassa_images_sanitize',
				'default'           => array(),
			)
		);
		register_setting(
			'anassa_images_group',
			ANASSA_GALLERIES_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => 'anassa_galleries_sanitize',
				'default'           => array(),
			)
		);
	}
);

add_action(
	'admin_menu',
	static function () {
		add_options_page( 'Εικόνες φόντου', 'Εικόνες φόντου', 'manage_options', 'anassa-images', 'anassa_images_page' );
	}
);

/* Η αποθήκευση — και η διαγραφή μιας εικόνας από τη Βιβλιοθήκη — καθαρίζει την
   προσωρινή μνήμη των δεδομένων της σελίδας. */
add_action( 'update_option_' . ANASSA_IMAGES_OPTION, 'anassa_flush_boot' );
add_action( 'add_option_' . ANASSA_IMAGES_OPTION, 'anassa_flush_boot' );
add_action( 'update_option_' . ANASSA_GALLERIES_OPTION, 'anassa_flush_boot' );
add_action( 'add_option_' . ANASSA_GALLERIES_OPTION, 'anassa_flush_boot' );
add_action( 'delete_attachment', 'anassa_flush_boot' );

/* Το παράθυρο επιλογής εικόνας του WordPress φορτώνει ΜΟΝΟ σε αυτή τη σελίδα. */
add_action(
	'admin_enqueue_scripts',
	static function ( $hook ) {
		if ( 'settings_page_anassa-images' !== $hook ) {
			return;
		}
		wp_enqueue_media();
	}
);

function anassa_images_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$saved     = anassa_images_get();
	$galleries = anassa_galleries_get();
	$n         = ANASSA_IMAGES_OPTION;
	?>
	<div class="wrap">
		<h1>Εικόνες φόντου</h1>
		<p>Διαλέξτε φωτογραφία για κάθε θέση από τη Βιβλιοθήκη Πολυμέσων (ή ανεβάστε νέα) και πατήστε «Αποθήκευση». Το site την δείχνει αμέσως. Αν δεν διαλέξετε τίποτα, ισχύει η προεπιλεγμένη φωτογραφία του site.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'anassa_images_group' ); ?>
			<table class="form-table" role="presentation">
			<?php
			$group = '';
			foreach ( anassa_images_registry() as $key => $def ) {
				$id    = isset( $saved[ $key ] ) ? (int) $saved[ $key ] : 0;
				$thumb = $id > 0 ? wp_get_attachment_image_url( $id, 'medium' ) : '';
				if ( $def[0] !== $group ) {
					$group = $def[0];
					echo '<tr><th colspan="2"><h2 style="margin:1.2em 0 0">' . esc_html( $group ) . '</h2></th></tr>';
				}
				?>
				<tr class="anassa-img-slot">
					<th scope="row"><?php echo esc_html( $def[1] ); ?></th>
					<td>
						<div class="anassa-img-preview" style="max-width:320px;margin-bottom:8px;background:#f0f0f1;border:1px solid #c3c4c7;min-height:60px">
							<?php if ( $thumb ) : ?>
								<img src="<?php echo esc_url( $thumb ); ?>" alt="" style="display:block;width:100%;height:auto">
							<?php else : ?>
								<p class="description" style="margin:0;padding:18px 12px">Προεπιλεγμένη φωτογραφία του site.</p>
							<?php endif; ?>
						</div>
						<input type="hidden" class="anassa-img-id" name="<?php echo esc_attr( $n . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( (string) $id ); ?>">
						<button type="button" class="button anassa-img-pick">Επιλογή εικόνας</button>
						<button type="button" class="button-link anassa-img-reset" style="margin-left:10px;<?php echo $id > 0 ? '' : 'display:none'; ?>">Επαναφορά στην προεπιλογή</button>
						<p class="description"><?php echo esc_html( $def[2] ); ?></p>
					</td>
				</tr>
				<?php
			}
			?>
			</table>

			<h2 style="margin-top:2em">Καρουζέλ φωτογραφιών</h2>
			<table class="form-table" role="presentation">
			<?php
			foreach ( anassa_galleries_registry() as $key => $def ) {
				$ids = isset( $galleries[ $key ] ) && is_array( $galleries[ $key ] ) ? array_map( 'intval', $galleries[ $key ] ) : array();
				?>
				<tr class="anassa-gal-slot">
					<th scope="row"><?php echo esc_html( $def[0] . ': ' . $def[1] ); ?></th>
					<td>
						<ul class="anassa-gal-list" style="display:flex;flex-wrap:wrap;gap:8px;margin:0 0 8px;padding:0;list-style:none">
							<?php foreach ( $ids as $gid ) : ?>
								<?php $th = wp_get_attachment_image_url( $gid, 'thumbnail' ); ?>
								<?php if ( $th ) : ?>
									<li data-id="<?php echo esc_attr( (string) $gid ); ?>" style="position:relative;width:96px">
										<img src="<?php echo esc_url( $th ); ?>" alt="" style="display:block;width:96px;height:64px;object-fit:cover;border:1px solid #c3c4c7">
										<button type="button" class="button-link anassa-gal-remove" aria-label="Αφαίρεση εικόνας" style="position:absolute;top:2px;right:4px;color:#b32d2e">&times;</button>
									</li>
								<?php endif; ?>
							<?php endforeach; ?>
						</ul>
						<input type="hidden" class="anassa-gal-ids" name="<?php echo esc_attr( ANASSA_GALLERIES_OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>">
						<button type="button" class="button anassa-gal-add">Προσθήκη εικόνων</button>
						<button type="button" class="button-link anassa-gal-clear" style="margin-left:10px">Επαναφορά στις προεπιλεγμένες</button>
						<p class="description"><?php echo esc_html( $def[2] ); ?></p>
					</td>
				</tr>
				<?php
			}
			?>
			</table>
			<?php submit_button( 'Αποθήκευση' ); ?>
		</form>
	</div>
	<script>
	(function () {
		var DEFAULT_HTML = '<p class="description" style="margin:0;padding:18px 12px">Προεπιλεγμένη φωτογραφία του site.</p>';

		document.querySelectorAll('.anassa-img-slot').forEach(function (row) {
			var idInput = row.querySelector('.anassa-img-id');
			var preview = row.querySelector('.anassa-img-preview');
			var reset = row.querySelector('.anassa-img-reset');
			var frame = null;
			row.querySelector('.anassa-img-pick').addEventListener('click', function () {
				if (!frame) {
					frame = wp.media({
						title: 'Επιλογή εικόνας φόντου',
						button: { text: 'Χρήση αυτής της εικόνας' },
						library: { type: 'image' },
						multiple: false
					});
					frame.on('select', function () {
						var att = frame.state().get('selection').first().toJSON();
						var src = (att.sizes && att.sizes.medium ? att.sizes.medium.url : att.url);
						idInput.value = att.id;
						preview.innerHTML = '';
						var img = document.createElement('img');
						img.src = src;
						img.alt = '';
						img.style.cssText = 'display:block;width:100%;height:auto';
						preview.appendChild(img);
						reset.style.display = '';
					});
				}
				frame.open();
			});
			reset.addEventListener('click', function () {
				idInput.value = '0';
				preview.innerHTML = DEFAULT_HTML;
				reset.style.display = 'none';
			});
		});

		document.querySelectorAll('.anassa-gal-slot').forEach(function (row) {
			var input = row.querySelector('.anassa-gal-ids');
			var list = row.querySelector('.anassa-gal-list');
			var frame = null;
			function sync() {
				var ids = [];
				list.querySelectorAll('li').forEach(function (li) { ids.push(li.getAttribute('data-id')); });
				input.value = ids.join(',');
			}
			function addItem(id, src) {
				if (list.querySelector('li[data-id="' + id + '"]')) { return; }
				var li = document.createElement('li');
				li.setAttribute('data-id', id);
				li.style.cssText = 'position:relative;width:96px';
				var img = document.createElement('img');
				img.src = src;
				img.alt = '';
				img.style.cssText = 'display:block;width:96px;height:64px;object-fit:cover;border:1px solid #c3c4c7';
				var x = document.createElement('button');
				x.type = 'button';
				x.className = 'button-link anassa-gal-remove';
				x.setAttribute('aria-label', 'Αφαίρεση εικόνας');
				x.style.cssText = 'position:absolute;top:2px;right:4px;color:#b32d2e';
				x.innerHTML = '&times;';
				li.appendChild(img);
				li.appendChild(x);
				list.appendChild(li);
			}
			list.addEventListener('click', function (e) {
				var btn = e.target.closest('.anassa-gal-remove');
				if (!btn) { return; }
				btn.closest('li').remove();
				sync();
			});
			row.querySelector('.anassa-gal-clear').addEventListener('click', function () {
				list.innerHTML = '';
				sync();
			});
			row.querySelector('.anassa-gal-add').addEventListener('click', function () {
				if (!frame) {
					frame = wp.media({
						title: 'Επιλογή φωτογραφιών για το καρουζέλ',
						button: { text: 'Προσθήκη στο καρουζέλ' },
						library: { type: 'image' },
						multiple: 'add'
					});
					frame.on('select', function () {
						frame.state().get('selection').each(function (att) {
							var a = att.toJSON();
							addItem(a.id, (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url));
						});
						sync();
					});
				}
				frame.open();
			});
		});
	})();
	</script>
	<?php
}
