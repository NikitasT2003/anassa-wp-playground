<?php
/**
 * Αρχική εισαγωγή: οι 12 εκδρομές του repo (`seed/trips.json`, γραμμένο από το
 * `npm run wp:theme`) γίνονται εκδρομές στο wp-admin με την ενεργοποίηση του
 * θέματος. Τρέχει μόνο όταν δεν υπάρχει καμία εκδρομή, ώστε μια
 * επανενεργοποίηση να μη διπλασιάσει τίποτα ούτε να επαναφέρει ό,τι έσβησε ο πελάτης.
 */

defined( 'ABSPATH' ) || exit;

function anassa_seed_trips( bool $force = false ): int {
	$file = ANASSA_DIR . '/seed/trips.json';
	if ( ! is_readable( $file ) ) {
		return 0;
	}
	if ( ! $force && post_type_exists( ANASSA_TRIP ) && wp_count_posts( ANASSA_TRIP )->publish > 0 ) {
		return 0;
	}
	$trips = json_decode( (string) file_get_contents( $file ), true );
	if ( ! is_array( $trips ) ) {
		return 0;
	}
	$created = 0;
	foreach ( $trips as $order => $trip ) {
		$id = wp_insert_post(
			array(
				'post_type'   => ANASSA_TRIP,
				'post_status' => 'publish',
				'post_title'  => $trip['title'],
				'post_name'   => $trip['slug'],
				'menu_order'  => $order,
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			continue;
		}
		anassa_trip_save_fields( $id, $trip );
		++$created;
	}
	if ( $created > 0 ) {
		update_option( 'anassa_seeded', 1 );
	}
	anassa_flush_boot();
	return $created;
}

/**
 * Δεύτερη ασφάλεια: αν το θέμα ήταν ήδη ενεργό (π.χ. το Playground το ενεργοποιεί
 * πριν από το blueprint, ή ανέβηκε πάνω από ενεργό θέμα), το `after_switch_theme`
 * δεν τρέχει ποτέ. Η εισαγωγή γίνεται ΜΙΑ φορά, στην πρώτη επίσκεψη διαχειριστή,
 * και το option εμποδίζει να ξαναγυρίσουν εκδρομές που έσβησε ο πελάτης.
 */
add_action(
	'admin_init',
	static function () {
		if ( get_option( 'anassa_seeded' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		/* Υπάρχουσες εκδρομές = ο πελάτης ξεκίνησε μόνος του· δεν πειράζουμε τίποτα. */
		if ( wp_count_posts( ANASSA_TRIP )->publish > 0 ) {
			update_option( 'anassa_seeded', 1 );
			return;
		}
		anassa_seed_trips();
	}
);

add_action(
	'after_switch_theme',
	static function () {
		/* Οι διαδρομές του site χρειάζονται «όμορφους» συνδέσμους. */
		if ( '' === (string) get_option( 'permalink_structure' ) ) {
			update_option( 'permalink_structure', '/%postname%/' );
		}
		anassa_register_for_seed();
		anassa_remove_sample_content();
		anassa_seed_trips();
		flush_rewrite_rules();
	}
);

/**
 * Κάθε νέα εγκατάσταση WordPress έρχεται με το άρθρο «Hello world!». Θα
 * εμφανιζόταν στο blog του site ως δημοσιευμένο άρθρο, οπότε φεύγει στην
 * ενεργοποίηση, ΑΝ δεν έχει αλλάξει (ίδιο slug και ίδιο κείμενο).
 */
function anassa_remove_sample_content(): void {
	/* Τα δύο δείγματα είναι πάντα τα posts με ID 1 και 2. «Αμεταβλήτο» σημαίνει
	   ότι η ημερομηνία τροποποίησης είναι ίδια με της δημιουργίας· ό,τι
	   επεξεργάστηκε κάποιος μένει. Δουλεύει σε κάθε γλώσσα εγκατάστασης. */
	foreach ( array( 1 => 'post', 2 => 'page' ) as $id => $type ) {
		$p = get_post( $id );
		if ( $p && $type === $p->post_type && $p->post_date_gmt === $p->post_modified_gmt ) {
			wp_delete_post( $id, true );
		}
	}
}

/** Στην ενεργοποίηση το `init` έχει ήδη τρέξει, οπότε οι τύποι υπάρχουν. */
function anassa_register_for_seed(): void {
	if ( ! post_type_exists( ANASSA_TRIP ) ) {
		do_action( 'init' );
	}
}

/* Χειροκίνητη επανεισαγωγή από διαχειριστή: /wp-admin/?anassa_seed=1 */
add_action(
	'admin_init',
	static function () {
		if ( isset( $_GET['anassa_seed'] ) && current_user_can( 'manage_options' ) && check_admin_referer( 'anassa_seed' ) ) {
			$n = anassa_seed_trips( true );
			wp_safe_redirect( admin_url( 'edit.php?post_type=' . ANASSA_TRIP . '&anassa_seeded=' . $n ) );
			exit;
		}
	}
);

add_action(
	'admin_notices',
	static function () {
		$screen = get_current_screen();
		if ( ! $screen || 'edit-' . ANASSA_TRIP !== $screen->id ) {
			return;
		}
		if ( isset( $_GET['anassa_seeded'] ) ) {
			printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( 'Εισήχθησαν ' . (int) $_GET['anassa_seeded'] . ' εκδρομές.' ) );
			return;
		}
		if ( 0 === (int) wp_count_posts( ANASSA_TRIP )->publish && is_readable( ANASSA_DIR . '/seed/trips.json' ) ) {
			printf(
				'<div class="notice notice-info"><p>Δεν υπάρχουν εκδρομές. <a href="%s">Εισαγωγή των 12 αρχικών εκδρομών</a></p></div>',
				esc_url( wp_nonce_url( admin_url( 'index.php?anassa_seed=1' ), 'anassa_seed' ) )
			);
		}
	}
);
