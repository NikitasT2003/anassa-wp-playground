<?php
/**
 * Σερβίρει το React site σε κάθε διαδρομή του front-end.
 *
 * Το WordPress δεν έχει σελίδες για το /ekdromes ή το /blog· τις ξέρει το React.
 * Γι' αυτό, στο `template_redirect`, αποφασίζουμε μόνοι μας αν η διαδρομή
 * υπάρχει (200) ή όχι (404, και το React δείχνει τη σελίδα «δεν βρέθηκε»),
 * γράφουμε το `window.__ANASSA__` και στέλνουμε το `app/index.html`.
 */

defined( 'ABSPATH' ) || exit;

/** Τα δεδομένα που περνούν στο React. Αποθηκεύονται μέχρι την επόμενη αλλαγή. */
function anassa_boot_data(): array {
	$cached = get_transient( 'anassa_boot_v5' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	if ( ! get_option( 'anassa_pages_seed_v' ) ) {
		anassa_seed_pages();
		update_option( 'anassa_pages_seed_v', 1 );
	}
	$trips = array_map( 'anassa_trip_payload', anassa_trip_posts() );
	$data  = array(
		'trips'      => $trips,
		'months'     => anassa_season_months( $trips ),
		'posts'      => anassa_blog_payload(),
		'enquiryApi' => rest_url( 'anassa/v1/enquiry' ),
		'indexable'  => (bool) get_option( 'blog_public' ),
		'origin'     => untrailingslashit( home_url() ),
		'announcement' => anassa_announcement_payload(),
		'nav'        => anassa_nav_payload(),
		'pages'      => anassa_pages_payload(),
		'texts'      => anassa_texts_payload(),
		'images'     => anassa_images_payload(),
		'galleries'  => anassa_galleries_payload(),
	);
	set_transient( 'anassa_boot_v5', $data, DAY_IN_SECONDS );
	return $data;
}

/** Αν η διαδρομή υπάρχει στο site (ώστε να απαντήσουμε 200 ή 404). */
function anassa_route_exists( string $path ): bool {
	$path = '/' . trim( $path, '/' );
	$m    = anassa_manifest();
	if ( in_array( $path, $m['static'], true ) ) {
		return true;
	}
	if ( preg_match( '#^/ekdromes/([^/]+)$#', $path, $hit ) ) {
		$slug = urldecode( $hit[1] );
		foreach ( anassa_boot_data()['trips'] as $trip ) {
			if ( $trip['slug'] === $slug ) {
				return true;
			}
		}
		return false;
	}
	if ( preg_match( '#^/blog/([^/]+)$#', $path, $hit ) ) {
		$slug = urldecode( $hit[1] );
		if ( in_array( $slug, $m['mdx'], true ) ) {
			return true;
		}
		foreach ( anassa_boot_data()['posts'] as $post ) {
			if ( $post['slug'] === $slug ) {
				return true;
			}
		}
	}
	return false;
}

function anassa_render_app(): void {
	$file = ANASSA_APP_DIR . '/index.html';
	if ( ! is_readable( $file ) ) {
		wp_die(
			esc_html( 'Λείπει το build του site (app/index.html). Τρέξτε «npm run wp:theme» στο showcase/anassa και ανεβάστε ξανά το θέμα.' ),
			'Anassa Holidays',
			array( 'response' => 500 )
		);
	}
	$html = (string) file_get_contents( $file );

	$boot = wp_json_encode( anassa_boot_data(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS );
	$tag  = '<script>window.__ANASSA__=' . $boot . ';</script>';
	$html = preg_replace( '#</head>#i', $tag . '</head>', $html, 1 );

	$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH );
	status_header( anassa_route_exists( $path ) ? 200 : 404 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: no-cache' );
	if ( ! get_option( 'blog_public' ) ) {
		header( 'X-Robots-Tag: noindex, nofollow' );
	}
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- build του θέματος + JSON με HEX_TAG.
	exit;
}

add_action(
	'template_redirect',
	static function () {
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? (string) $_SERVER['REQUEST_METHOD'] : 'GET';
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) || is_feed() || is_robots() || is_embed() ) {
			return;
		}
		anassa_render_app();
	},
	1
);

/* Τα URL του React δεν έχουν τελική κάθετο ούτε είναι σελίδες του WordPress. */
add_filter( 'redirect_canonical', '__return_false' );

/* Τα αρχεία του build (JS, εικόνες, βίντεο) ζουν στο `app/` και τα σερβίρει ο
   web server απευθείας. Το favicon και το manifest ζουν στη ρίζα του `app/`,
   οπότε τα δηλώνει ήδη το index.html. */
