<?php
/**
 * Εκδρομές: τύπος περιεχομένου, φόρμα επεξεργασίας στο wp-admin, και η
 * μετατροπή τους στο σχήμα `Trip` του `src/lib/data.ts`.
 *
 * ΤΟ ΣΧΗΜΑ ΕΙΝΑΙ ΣΥΜΒΟΛΑΙΟ. Το `anassa_trip_payload()` πρέπει να βγάζει ακριβώς
 * τα πεδία του τύπου `Trip`. Αν προστεθεί πεδίο εκεί, προστίθεται και εδώ — στο
 * `anassa_trip_fields()` για τη φόρμα και στο payload για το React.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_TRIP = 'anassa_trip';

const ANASSA_MONTHS = array(
	1  => 'Ιανουάριος',
	2  => 'Φεβρουάριος',
	3  => 'Μάρτιος',
	4  => 'Απρίλιος',
	5  => 'Μάιος',
	6  => 'Ιούνιος',
	7  => 'Ιούλιος',
	8  => 'Αύγουστος',
	9  => 'Σεπτέμβριος',
	10 => 'Οκτώβριος',
	11 => 'Νοέμβριος',
	12 => 'Δεκέμβριος',
);

add_action(
	'init',
	static function () {
		register_post_type(
			ANASSA_TRIP,
			array(
				'labels'          => array(
					'name'               => 'Εκδρομές',
					'singular_name'      => 'Εκδρομή',
					'add_new'            => 'Νέα εκδρομή',
					'add_new_item'       => 'Νέα εκδρομή',
					'edit_item'          => 'Επεξεργασία εκδρομής',
					'new_item'           => 'Νέα εκδρομή',
					'view_item'          => 'Προβολή εκδρομής',
					'search_items'       => 'Αναζήτηση εκδρομών',
					'not_found'          => 'Δεν βρέθηκαν εκδρομές',
					'not_found_in_trash' => 'Δεν υπάρχουν εκδρομές στον κάδο',
					'all_items'          => 'Όλες οι εκδρομές',
					'featured_image'     => 'Φωτογραφία εκδρομής',
					'set_featured_image' => 'Ορισμός φωτογραφίας',
					'remove_featured_image' => 'Αφαίρεση φωτογραφίας',
					'use_featured_image' => 'Χρήση ως φωτογραφία εκδρομής',
				),
				/* Όχι δημόσιο: τη σελίδα της εκδρομής την αποδίδει το React στο
				   /ekdromes/<slug>, όχι το WordPress. */
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'show_in_rest'    => false,
				'menu_position'   => 5,
				'menu_icon'       => 'dashicons-location-alt',
				'supports'        => array( 'title', 'thumbnail', 'page-attributes' ),
				'capability_type' => 'post',
				'map_meta_cap'    => true,
			)
		);
	}
);

/**
 * Τα πεδία της φόρμας, με τη σειρά που εμφανίζονται.
 *
 * @return array<string, array<string, mixed>>
 */
function anassa_trip_fields(): array {
	return array(
		'region'       => array(
			'label'   => 'Ελλάδα ή εξωτερικό',
			'type'    => 'select',
			'options' => array( 'Ελλάδα' => 'Ελλάδα', 'Εξωτερικό' => 'Εξωτερικό' ),
		),
		'area'         => array(
			'label' => 'Περιοχή',
			'type'  => 'text',
			'help'  => 'Π.χ. «Ιόνιο», «Βαλκάνια», «Ήπειρος & Θεσσαλία». Εμφανίζεται στην κάρτα και γίνεται φίλτρο.',
		),
		'transport'    => array(
			'label'   => 'Μετακίνηση',
			'type'    => 'select',
			'options' => array( 'Οδικώς' => 'Οδικώς', 'Αεροπορικώς' => 'Αεροπορικώς', 'Ακτοπλοϊκώς' => 'Ακτοπλοϊκώς' ),
		),
		'dateLabel'    => array(
			'label' => 'Ημερομηνίες',
			'type'  => 'text',
			'help'  => 'Ακριβώς στη μορφή ΗΗ.ΜΜ – ΗΗ.ΜΜ, π.χ. «11.09 – 13.09». Από εδώ βγαίνουν ο μήνας, το ημερολόγιο αναχωρήσεων και η σειρά στον κατάλογο.',
		),
		'days'         => array( 'label' => 'Ημέρες', 'type' => 'number' ),
		'nights'       => array( 'label' => 'Διανυκτερεύσεις', 'type' => 'number' ),
		'priceFrom'    => array(
			'label' => 'Τιμή από (€)',
			'type'  => 'number',
			'help'  => 'Ακέραιος αριθμός, χωρίς το σύμβολο €.',
		),
		'availability' => array(
			'label'   => 'Διαθεσιμότητα',
			'type'    => 'select',
			'options' => array(
				'available' => 'Διαθέσιμη',
				'few'       => 'Λίγες θέσεις',
				'full'      => 'Πλήρης',
			),
		),
		'hook'         => array(
			'label' => 'Μία πρόταση: γιατί εδώ',
			'type'  => 'textarea',
			'rows'  => 2,
			'help'  => 'Η φράση της κάρτας. Μία ειλικρινής πρόταση για τον προορισμό, χωρίς υπερθετικά.',
		),
		'intro'        => array(
			'label' => 'Εισαγωγή',
			'type'  => 'textarea',
			'rows'  => 4,
		),
		'itinerary'    => array(
			'label' => 'Πρόγραμμα',
			'type'  => 'lines',
			'rows'  => 6,
			'help'  => 'Μία ημέρα ανά γραμμή, με κάθετη γραμμή ανάμεσα: «1η ημέρα | Αναχώρηση από Αθήνα…».',
		),
		'included'     => array(
			'label' => 'Περιλαμβάνονται',
			'type'  => 'lines',
			'rows'  => 4,
			'help'  => 'Ένα ανά γραμμή.',
		),
		'excluded'     => array(
			'label' => 'Δεν περιλαμβάνονται',
			'type'  => 'lines',
			'rows'  => 3,
			'help'  => 'Ένα ανά γραμμή.',
		),
		'hotels'       => array(
			'label' => 'Ξενοδοχεία',
			'type'  => 'lines',
			'rows'  => 2,
			'help'  => 'Ένα ανά γραμμή.',
		),
		'photoAlt'     => array(
			'label' => 'Περιγραφή φωτογραφίας',
			'type'  => 'text',
			'help'  => 'Τι δείχνει η φωτογραφία, για όσους δεν τη βλέπουν. Π.χ. «Οι βράχοι των Μετεώρων μέσα στην πρωινή ομίχλη».',
		),
		'programPdfId' => array(
			'label' => 'Πρόγραμμα σε PDF',
			'type'  => 'pdf',
			'help'  => 'Το αρχείο που κατεβάζει ο επισκέπτης από το κουμπί «Πρόγραμμα (PDF)» στη σελίδα της εκδρομής. Χωρίς αρχείο, το κουμπί ανοίγει την εκτύπωση της σελίδας.',
		),
		'galleryIds'   => array(
			'label' => 'Επιπλέον φωτογραφίες (προορισμοί)',
			'type'  => 'text',
			'help'  => 'Για εκδρομή με πολλούς προορισμούς: οι αριθμοί (ID) των φωτογραφιών από τη Βιβλιοθήκη Πολυμέσων, χωρισμένοι με κόμμα, π.χ. «41, 42». Η πρώτη φωτογραφία είναι η «Φωτογραφία εκδρομής» δεξιά· αυτές ακολουθούν και το banner γίνεται καρουζέλ. Κενό = μία φωτογραφία.',
		),
		'plate'        => array(
			'label' => 'Χρώμα φόντου (όσο φορτώνει η φωτογραφία)',
			'type'  => 'colors',
		),
	);
}

add_action(
	'add_meta_boxes',
	static function () {
		add_meta_box( 'anassa_trip_details', 'Στοιχεία εκδρομής', 'anassa_trip_metabox', ANASSA_TRIP, 'normal', 'high' );
	}
);

/** Η τιμή ενός πεδίου όπως αποθηκεύτηκε, ή κενό. */
function anassa_trip_meta( int $post_id, string $key ) {
	return get_post_meta( $post_id, '_anassa_' . $key, true );
}

function anassa_trip_metabox( WP_Post $post ): void {
	wp_nonce_field( 'anassa_trip_save', 'anassa_trip_nonce' );
	wp_enqueue_media(); // το παράθυρο επιλογής PDF
	$slug = $post->post_name;
	?>
	<style>
		.anassa-fields{display:grid;gap:16px;max-width:760px}
		.anassa-fields label{display:block;font-weight:600;margin-bottom:4px}
		.anassa-fields input[type=text],.anassa-fields input[type=number],.anassa-fields select,.anassa-fields textarea{width:100%}
		.anassa-fields .help{color:#646970;margin:4px 0 0}
		.anassa-two{display:grid;grid-template-columns:1fr 1fr;gap:16px}
	</style>
	<div class="anassa-fields">
		<p>
			<label for="anassa_slug">Διεύθυνση</label>
			<code><?php echo esc_html( home_url( '/ekdromes/' ) ); ?></code><input type="text" id="anassa_slug" name="anassa[slug]" value="<?php echo esc_attr( urldecode( $slug ) ); ?>" style="width:auto;min-width:260px">
			<span class="help">Λατινικά, π.χ. «meteora-zagorochoria». Αν μείνει κενό, φτιάχνεται από τον τίτλο. Αν αλλάξει σε εκδρομή που ήδη κυκλοφορεί, οι παλιοί σύνδεσμοι σταματούν να δουλεύουν.</span>
		</p>
		<?php
		foreach ( anassa_trip_fields() as $key => $field ) {
			$value = anassa_trip_meta( $post->ID, $key );
			$id    = 'anassa_' . $key;
			$name  = 'anassa[' . $key . ']';
			echo '<div>';
			printf( '<label for="%s">%s</label>', esc_attr( $id ), esc_html( $field['label'] ) );
			switch ( $field['type'] ) {
				case 'select':
					printf( '<select id="%s" name="%s">', esc_attr( $id ), esc_attr( $name ) );
					foreach ( $field['options'] as $opt_value => $opt_label ) {
						printf( '<option value="%s"%s>%s</option>', esc_attr( $opt_value ), selected( $value, $opt_value, false ), esc_html( $opt_label ) );
					}
					echo '</select>';
					break;
				case 'number':
					printf( '<input type="number" min="0" step="1" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
					break;
				case 'textarea':
					printf( '<textarea id="%s" name="%s" rows="%d">%s</textarea>', esc_attr( $id ), esc_attr( $name ), (int) $field['rows'], esc_textarea( (string) $value ) );
					break;
				case 'lines':
					$lines = is_array( $value ) ? $value : array();
					if ( 'itinerary' === $key ) {
						$lines = array_map( static fn( $row ) => $row['day'] . ' | ' . $row['text'], $lines );
					}
					printf( '<textarea id="%s" name="%s" rows="%d">%s</textarea>', esc_attr( $id ), esc_attr( $name ), (int) $field['rows'], esc_textarea( implode( "\n", $lines ) ) );
					break;
				case 'pdf':
					$pdf_id   = (int) $value;
					$pdf_name = $pdf_id ? basename( (string) get_attached_file( $pdf_id ) ) : '';
					printf( '<input type="hidden" id="%s" name="%s" value="%d">', esc_attr( $id ), esc_attr( $name ), $pdf_id );
					printf( '<span class="anassa-pdf-name" data-for="%s">%s</span> ', esc_attr( $id ), esc_html( $pdf_name ? $pdf_name : 'Δεν έχει επιλεγεί αρχείο.' ) );
					printf( '<button type="button" class="button anassa-pdf-pick" data-for="%s">Επιλογή ή ανέβασμα PDF</button> ', esc_attr( $id ) );
					printf( '<button type="button" class="button-link anassa-pdf-clear" data-for="%s"%s>Αφαίρεση</button>', esc_attr( $id ), $pdf_id ? '' : ' hidden' );
					break;
				case 'colors':
					$colors = is_array( $value ) && 2 === count( $value ) ? $value : array( '#2C6E9B', '#123A5C' );
					printf( '<input type="color" name="%s[0]" value="%s"> ', esc_attr( $name ), esc_attr( $colors[0] ) );
					printf( '<input type="color" name="%s[1]" value="%s">', esc_attr( $name ), esc_attr( $colors[1] ) );
					break;
				default:
					printf( '<input type="text" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
			}
			if ( ! empty( $field['help'] ) ) {
				printf( '<p class="help">%s</p>', esc_html( $field['help'] ) );
			}
			echo '</div>';
		}
		?>
		<script>
			/* Επιλογή PDF από τη Βιβλιοθήκη Πολυμέσων: ίδιο παράθυρο με το WordPress, μόνο PDF. */
			document.addEventListener( 'click', function ( e ) {
				var pick = e.target.closest( '.anassa-pdf-pick' ), clear = e.target.closest( '.anassa-pdf-clear' );
				if ( ! pick && ! clear ) { return; }
				var id = ( pick || clear ).dataset.for,
					input = document.getElementById( id ),
					label = document.querySelector( '.anassa-pdf-name[data-for="' + id + '"]' ),
					remove = document.querySelector( '.anassa-pdf-clear[data-for="' + id + '"]' );
				if ( clear ) {
					input.value = 0; label.textContent = 'Δεν έχει επιλεγεί αρχείο.'; remove.hidden = true; return;
				}
				var frame = wp.media( { title: 'Πρόγραμμα σε PDF', button: { text: 'Χρήση αυτού του αρχείου' }, library: { type: 'application/pdf' }, multiple: false } );
				frame.on( 'select', function () {
					var file = frame.state().get( 'selection' ).first().toJSON();
					input.value = file.id; label.textContent = file.filename; remove.hidden = false;
				} );
				frame.open();
			} );
			</script>
			<p class="help">Η φωτογραφία ορίζεται από το κουτί «Φωτογραφία εκδρομής» δεξιά. Χωρίς δική της φωτογραφία, η εκδρομή χρησιμοποιεί τη φωτογραφία του αρχικού σετ με το ίδιο slug, αν υπάρχει.</p>
	</div>
	<?php
}

/** «ΗΗ.ΜΜ – ΗΗ.ΜΜ» → αριθμός μήνα αναχώρησης, ή 0. */
function anassa_trip_start_month( string $date_label ): int {
	if ( preg_match( '/^\s*(\d{2})\.(\d{2})/', $date_label, $m ) ) {
		$month = (int) $m[2];
		return $month >= 1 && $month <= 12 ? $month : 0;
	}
	return 0;
}

add_action(
	'save_post_' . ANASSA_TRIP,
	static function ( int $post_id ) {
		if ( ! isset( $_POST['anassa_trip_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['anassa_trip_nonce'] ), 'anassa_trip_save' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$input = isset( $_POST['anassa'] ) && is_array( $_POST['anassa'] ) ? wp_unslash( $_POST['anassa'] ) : array();
		anassa_trip_save_fields( $post_id, $input );
	}
);

/**
 * Καθαρίζει και αποθηκεύει τα πεδία. Το χρησιμοποιεί και η αρχική εισαγωγή.
 *
 * @param array<string, mixed> $input
 */
function anassa_trip_save_fields( int $post_id, array $input ): void {
	foreach ( anassa_trip_fields() as $key => $field ) {
		$raw = $input[ $key ] ?? null;
		switch ( $field['type'] ) {
			case 'select':
				$value = is_string( $raw ) && array_key_exists( $raw, $field['options'] ) ? $raw : array_key_first( $field['options'] );
				break;
			case 'number':
				$value = max( 0, (int) $raw );
				break;
			case 'textarea':
				$value = sanitize_textarea_field( (string) $raw );
				break;
			case 'lines':
				$lines = is_array( $raw ) ? $raw : preg_split( '/\r\n|\r|\n/', (string) $raw );
				$value = array();
				foreach ( $lines as $line ) {
					if ( 'itinerary' === $key ) {
						if ( is_array( $line ) ) {
							$day  = sanitize_text_field( (string) ( $line['day'] ?? '' ) );
							$text = sanitize_text_field( (string) ( $line['text'] ?? '' ) );
						} else {
							$parts = array_map( 'trim', explode( '|', (string) $line, 2 ) );
							$day   = sanitize_text_field( $parts[0] );
							$text  = sanitize_text_field( $parts[1] ?? '' );
						}
						if ( '' !== $day || '' !== $text ) {
							$value[] = array( 'day' => $day, 'text' => $text );
						}
					} else {
						$clean = sanitize_text_field( (string) $line );
						if ( '' !== $clean ) {
							$value[] = $clean;
						}
					}
				}
				break;
			case 'pdf':
				$pdf_id = absint( $raw );
				$value  = $pdf_id && 'application/pdf' === get_post_mime_type( $pdf_id ) ? $pdf_id : 0;
				break;
			case 'colors':
				$pair  = is_array( $raw ) ? array_values( $raw ) : array();
				$value = array(
					sanitize_hex_color( (string) ( $pair[0] ?? '' ) ) ?: '#2C6E9B',
					sanitize_hex_color( (string) ( $pair[1] ?? '' ) ) ?: '#123A5C',
				);
				break;
			default:
				$value = sanitize_text_field( (string) $raw );
		}
		update_post_meta( $post_id, '_anassa_' . $key, $value );
	}

	/* Το slug είναι το post_name. Γράφεται εδώ και όχι από το κουτί «Σύντομο
	   όνομα» του WordPress, γιατί ο τύπος δεν είναι δημόσιος και δεν το έχει. */
	if ( isset( $input['slug'] ) ) {
		$slug = anassa_slugify( (string) $input['slug'] );
		$post = get_post( $post_id );
		if ( $post && '' !== $slug && $slug !== $post->post_name ) {
			remove_all_actions( 'save_post_' . ANASSA_TRIP );
			wp_update_post( array( 'ID' => $post_id, 'post_name' => wp_unique_post_slug( $slug, $post_id, $post->post_status, ANASSA_TRIP, 0 ) ) );
		}
	}
}

/**
 * Μία φωτογραφία του WordPress στο σχήμα `Photo` του `src/lib/media.ts`.
 *
 * @return array{avif:string,webp:string,src:string,width:int,height:int}|null
 */
function anassa_photo( int $attachment_id ): ?array {
	$meta = wp_get_attachment_metadata( $attachment_id );
	$src  = wp_get_attachment_image_url( $attachment_id, 'large' );
	if ( ! $src || ! is_array( $meta ) ) {
		return null;
	}
	$srcset = wp_get_attachment_image_srcset( $attachment_id, 'full' );
	return array(
		'avif'   => '',
		'webp'   => $srcset ? $srcset : $src . ' ' . (int) ( $meta['width'] ?? 1200 ) . 'w',
		'src'    => $src,
		'width'  => (int) ( $meta['width'] ?? 1200 ),
		'height' => (int) ( $meta['height'] ?? 800 ),
	);
}

/**
 * Μία εκδρομή στο σχήμα `Trip` του React.
 *
 * @return array<string, mixed>
 */
function anassa_trip_payload( WP_Post $post ): array {
	$get        = static fn( string $key ) => anassa_trip_meta( $post->ID, $key );
	$date_label = (string) $get( 'dateLabel' );
	$month      = anassa_trip_start_month( $date_label );
	$plate      = $get( 'plate' );

	$trip = array(
		'slug'         => urldecode( $post->post_name ),
		'title'        => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
		'region'       => (string) ( $get( 'region' ) ?: 'Ελλάδα' ),
		'area'         => (string) $get( 'area' ),
		'transport'    => (string) ( $get( 'transport' ) ?: 'Οδικώς' ),
		'nights'       => (int) $get( 'nights' ),
		'days'         => max( 1, (int) $get( 'days' ) ),
		'dateLabel'    => $date_label,
		'month'        => $month ? ANASSA_MONTHS[ $month ] : '',
		'priceFrom'    => (int) $get( 'priceFrom' ),
		'availability' => (string) ( $get( 'availability' ) ?: 'available' ),
		'hook'         => (string) $get( 'hook' ),
		'intro'        => (string) $get( 'intro' ),
		'itinerary'    => is_array( $get( 'itinerary' ) ) ? array_values( $get( 'itinerary' ) ) : array(),
		'included'     => is_array( $get( 'included' ) ) ? array_values( $get( 'included' ) ) : array(),
		'excluded'     => is_array( $get( 'excluded' ) ) ? array_values( $get( 'excluded' ) ) : array(),
		'hotels'       => is_array( $get( 'hotels' ) ) ? array_values( $get( 'hotels' ) ) : array(),
		'plate'        => is_array( $plate ) && 2 === count( $plate ) ? array_values( $plate ) : array( '#2C6E9B', '#123A5C' ),
	);

	$alt = (string) $get( 'photoAlt' );
	if ( '' !== $alt ) {
		$trip['photoAlt'] = $alt;
	}

	/* Το PDF του προγράμματος: μόνο αν το συνημμένο υπάρχει ακόμη και είναι PDF. */
	$pdf_id = (int) $get( 'programPdfId' );
	if ( $pdf_id && 'application/pdf' === get_post_mime_type( $pdf_id ) ) {
		$pdf_url = wp_get_attachment_url( $pdf_id );
		if ( $pdf_url ) {
			$trip['programPdf'] = $pdf_url;
		}
	}

	$thumb = (int) get_post_thumbnail_id( $post );
	if ( $thumb ) {
		$photo = anassa_photo( $thumb );
		if ( $photo ) {
			$trip['photos'] = array( 'card' => $photo, 'wide' => $photo );

			/* Καρουζέλ: οι επιπλέον φωτογραφίες μετά την κύρια. Το alt είναι το
			   κείμενο εναλλακτικής περιγραφής του συνημμένου, αλλιώς ο τίτλος. */
			$gallery = array();
			foreach ( preg_split( '/[\s,]+/', (string) $get( 'galleryIds' ), -1, PREG_SPLIT_NO_EMPTY ) as $raw_id ) {
				$extra = anassa_photo( (int) $raw_id );
				if ( $extra ) {
					$alt_text  = trim( (string) get_post_meta( (int) $raw_id, '_wp_attachment_image_alt', true ) );
					$gallery[] = array(
						'wide' => $extra,
						'alt'  => '' !== $alt_text ? $alt_text : get_the_title( (int) $raw_id ),
					);
				}
			}
			if ( $gallery ) {
				$trip['photos']['gallery'] = $gallery;
			}
		}
	}
	return $trip;
}

/**
 * Οι δημοσιευμένες εκδρομές, με τη σειρά του πεδίου «Σειρά» και μετά τίτλου.
 *
 * @return WP_Post[]
 */
function anassa_trip_posts(): array {
	return get_posts(
		array(
			'post_type'        => ANASSA_TRIP,
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			'suppress_filters' => false,
		)
	);
}

/**
 * Οι μήνες της σεζόν με σειρά, όπως τους θέλει το `MONTHS` του `data.ts`: από
 * τον τρέχοντα μήνα και μετά, ώστε μια σεζόν Νοε → Φεβ να μπαίνει σωστά.
 *
 * @param array<int, array<string, mixed>> $trips
 * @return string[]
 */
function anassa_season_months( array $trips ): array {
	$now    = (int) wp_date( 'n' );
	$months = array();
	foreach ( $trips as $trip ) {
		$m = anassa_trip_start_month( (string) $trip['dateLabel'] );
		if ( $m ) {
			$months[ $m ] = ( $m - $now + 12 ) % 12;
		}
	}
	asort( $months );
	return array_values( array_map( static fn( $m ) => ANASSA_MONTHS[ $m ], array_keys( $months ) ) );
}

/* ---------------------------------------------------------------------------
   Η λίστα στο wp-admin: ημερομηνίες, τιμή και διαθεσιμότητα με μια ματιά.
   --------------------------------------------------------------------------- */
add_filter(
	'manage_' . ANASSA_TRIP . '_posts_columns',
	static function ( array $columns ): array {
		return array(
			'cb'           => $columns['cb'],
			'title'        => 'Εκδρομή',
			'anassa_dates' => 'Ημερομηνίες',
			'anassa_price' => 'Από',
			'anassa_avail' => 'Διαθεσιμότητα',
			'date'         => $columns['date'],
		);
	}
);

add_action(
	'manage_' . ANASSA_TRIP . '_posts_custom_column',
	static function ( string $column, int $post_id ) {
		$labels = anassa_trip_fields()['availability']['options'];
		switch ( $column ) {
			case 'anassa_dates':
				echo esc_html( (string) anassa_trip_meta( $post_id, 'dateLabel' ) );
				break;
			case 'anassa_price':
				echo esc_html( (int) anassa_trip_meta( $post_id, 'priceFrom' ) . ' €' );
				break;
			case 'anassa_avail':
				echo esc_html( $labels[ (string) anassa_trip_meta( $post_id, 'availability' ) ] ?? '' );
				break;
		}
	},
	10,
	2
);

/* Το «Προβολή» της λίστας ανοίγει τη σελίδα της εκδρομής στο site. */
add_filter(
	'post_row_actions',
	static function ( array $actions, WP_Post $post ): array {
		if ( ANASSA_TRIP === $post->post_type && 'publish' === $post->post_status ) {
			$actions['view'] = sprintf( '<a href="%s" target="_blank">Προβολή</a>', esc_url( home_url( '/ekdromes/' . $post->post_name ) ) );
		}
		return $actions;
	},
	10,
	2
);
