<?php
/**
 * Κοινά εργαλεία του θέματος.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Το `app/routes.json` που γράφει το `scripts/build-wp-theme.mjs`: οι σταθερές
 * διαδρομές του site, τα άρθρα που ζουν ως .mdx μέσα στο build, το lastmod τους
 * και η `base` με την οποία χτίστηκε.
 *
 * @return array{base:string,static:string[],mdx:string[],excluded:string[],lastmod:array<string,string>,builtAt:string}
 */
function anassa_manifest(): array {
	static $manifest = null;
	if ( null === $manifest ) {
		$file     = ANASSA_APP_DIR . '/routes.json';
		$decoded  = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null;
		$manifest = is_array( $decoded ) ? $decoded : array();
		$manifest += array(
			'base'     => '/wp-content/themes/anassa/app/',
			'static'   => array( '/' ),
			'mdx'      => array(),
			'excluded' => array(),
			'lastmod'  => array(),
			'builtAt'  => '',
		);
	}
	return $manifest;
}

/**
 * Ελληνικά → λατινικά για slugs, με τον ίδιο τρόπο που είναι γραμμένα τα slugs
 * των εκδρομών του repo («Μετέωρα & Ζαγοροχώρια» → «meteora-zagorochoria»).
 * Χωρίς αυτό το WordPress κρατά το ελληνικό slug κωδικοποιημένο
 * («%ce%bc%ce%b5…»), που γίνεται URL αδιάβαστο και σπάει στις κοινοποιήσεις.
 */
function anassa_slugify( string $text ): string {
	$text = mb_strtolower( $text, 'UTF-8' );
	$text = strtr(
		$text,
		array(
			'ά' => 'α', 'έ' => 'ε', 'ή' => 'η', 'ί' => 'ι', 'ϊ' => 'ι', 'ΐ' => 'ι',
			'ό' => 'ο', 'ύ' => 'υ', 'ϋ' => 'υ', 'ΰ' => 'υ', 'ώ' => 'ω',
		)
	);
	$text = strtr(
		$text,
		array(
			'ου' => 'ou', 'θ' => 'th', 'χ' => 'ch', 'ψ' => 'ps',
			'α' => 'a', 'β' => 'v', 'γ' => 'g', 'δ' => 'd', 'ε' => 'e', 'ζ' => 'z',
			'η' => 'i', 'ι' => 'i', 'κ' => 'k', 'λ' => 'l', 'μ' => 'm', 'ν' => 'n',
			'ξ' => 'x', 'ο' => 'o', 'π' => 'p', 'ρ' => 'r', 'σ' => 's', 'ς' => 's',
			'τ' => 't', 'υ' => 'y', 'φ' => 'f', 'ω' => 'o',
		)
	);
	$text = remove_accents( $text );
	$text = preg_replace( '/[^a-z0-9]+/', '-', $text );
	return trim( (string) $text, '-' );
}

/**
 * Κάθε εκδρομή και κάθε άρθρο παίρνει λατινικό slug. Αν ο χρήστης έγραψε δικό
 * του λατινικό slug, μένει· αν το WordPress έβγαλε κωδικοποιημένο ελληνικό ή
 * δεν υπάρχει καθόλου, το φτιάχνουμε από τον τίτλο.
 */
add_filter(
	'wp_insert_post_data',
	static function ( array $data ): array {
		if ( ! in_array( $data['post_type'], array( 'post', ANASSA_TRIP ), true ) ) {
			return $data;
		}
		if ( in_array( $data['post_status'], array( 'auto-draft', 'trash' ), true ) ) {
			return $data;
		}
		$name = urldecode( (string) $data['post_name'] );
		if ( '' === $name || preg_match( '/[^a-z0-9-]/', $name ) ) {
			$slug = anassa_slugify( '' !== $name ? $name : (string) $data['post_title'] );
			if ( '' !== $slug ) {
				$data['post_name'] = $slug;
			}
		}
		return $data;
	}
);

/** Το περιεχόμενο που περνά στο React αποθηκεύεται και σβήνεται σε κάθε αλλαγή. */
function anassa_flush_boot(): void {
	delete_transient( 'anassa_boot_v5' );
}
add_action( 'save_post', 'anassa_flush_boot' );
add_action( 'deleted_post', 'anassa_flush_boot' );
add_action( 'switch_theme', 'anassa_flush_boot' );
add_action( 'update_option_blog_public', 'anassa_flush_boot' );
add_action( 'edited_post_tag', 'anassa_flush_boot' );
