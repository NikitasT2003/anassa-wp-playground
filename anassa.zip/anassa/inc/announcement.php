<?php
/**
 * Η μπάρα ανακοίνωσης πάνω από την κεφαλίδα. Από 10.10.2026 είναι ΜΠΑΡΑ
 * ΕΓΓΡΑΦΗΣ ΣΤΟ NEWSLETTER (εντολή ιδιοκτήτη: «make the announcement banner have
 * the newsletter, the banner should be also editable»): ένα μήνυμα και ένα
 * κουμπί «Εγγραφή» που ανοίγει email + συναίνεση μέσα στη μπάρα. Οι εγγραφές
 * φτάνουν στο wp-admin → Αιτήματα, όπως του υποσέλιδου.
 *
 * Όλα τα κείμενα αλλάζουν στο wp-admin, «Ρυθμίσεις → Ανακοίνωση». Τα ελληνικά
 * πεδία δεν μένουν κενά· τα αγγλικά είναι προαιρετικά (κενό = ενσωματωμένη
 * μετάφραση ή το ελληνικό).
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_ANNOUNCEMENT_OPTION = 'anassa_announcement';

/** Τα πεδία κειμένου: κλειδί => [ετικέτα, βοήθεια]. */
function anassa_announcement_fields(): array {
	return array(
		'badge'   => array( 'Ετικέτα (π.χ. ΝΕΟ)', 'Το μικρό σήμα αριστερά. Κενό = δεν εμφανίζεται.' ),
		'message' => array( 'Μήνυμα', 'Μία πρόταση. Στο κινητό φαίνεται το «Σύντομο μήνυμα».' ),
		'short'   => array( 'Σύντομο μήνυμα (κινητό)', 'Λίγες λέξεις, για μικρές οθόνες.' ),
		'button'  => array( 'Κουμπί', 'Το κουμπί που ανοίγει τη φόρμα, π.χ. «Εγγραφή».' ),
		'consent' => array( 'Κείμενο συναίνεσης', 'Δίπλα στο τικ. Ο σύνδεσμος «Πολιτική Απορρήτου» προστίθεται αυτόματα.' ),
		'thanks'  => array( 'Μήνυμα μετά την εγγραφή', '' ),
	);
}

/** Οι αρχικές τιμές. */
function anassa_announcement_defaults(): array {
	$d = array(
		'enabled' => 1,
		'badge'   => 'ΝΕΟ',
		'message' => 'Μάθετε πρώτοι για τις εκδρομές και τις προσφορές μας.',
		'short'   => 'Newsletter',
		'button'  => 'Εγγραφή',
		'consent' => 'Συναινώ στη λήψη newsletters και στην αποθήκευση του email μου.',
		'thanks'  => 'Σας ευχαριστούμε! Η εγγραφή σας καταχωρήθηκε.',
	);
	foreach ( array_keys( anassa_announcement_fields() ) as $k ) {
		$d[ $k . '_en' ] = '';
	}
	return $d;
}

function anassa_announcement_get(): array {
	$saved = get_option( ANASSA_ANNOUNCEMENT_OPTION );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), anassa_announcement_defaults() );
}

/** Ό,τι περνά στο React. `null` = η μπάρα είναι κλειστή. */
function anassa_announcement_payload(): ?array {
	$a = anassa_announcement_get();
	if ( empty( $a['enabled'] ) ) {
		return null;
	}
	$out = array();
	foreach ( array_keys( anassa_announcement_fields() ) as $k ) {
		$out[ $k ]         = (string) $a[ $k ];
		$out[ $k . 'En' ] = (string) $a[ $k . '_en' ];
	}
	return $out;
}

function anassa_announcement_sanitize( $in ): array {
	$in  = is_array( $in ) ? $in : array();
	$def = anassa_announcement_defaults();
	$out = array( 'enabled' => empty( $in['enabled'] ) ? 0 : 1 );
	foreach ( array_keys( anassa_announcement_fields() ) as $k ) {
		foreach ( array( $k, $k . '_en' ) as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_text_field( wp_unslash( $in[ $key ] ) ) : $def[ $key ];
		}
		/* Το ελληνικό μήνυμα και το κουμπί δεν μένουν κενά. */
		if ( in_array( $k, array( 'message', 'button', 'consent' ), true ) && '' === $out[ $k ] ) {
			$out[ $k ] = $def[ $k ];
		}
	}
	return $out;
}

add_action(
	'admin_init',
	static function () {
		register_setting(
			'anassa_announcement_group',
			ANASSA_ANNOUNCEMENT_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => 'anassa_announcement_sanitize',
				'default'           => anassa_announcement_defaults(),
			)
		);
	}
);

add_action(
	'admin_menu',
	static function () {
		add_options_page( 'Ανακοίνωση', 'Ανακοίνωση', 'manage_options', 'anassa-announcement', 'anassa_announcement_page' );
	}
);

/* Η αποθήκευση καθαρίζει την προσωρινή μνήμη των δεδομένων της σελίδας. */
add_action( 'update_option_' . ANASSA_ANNOUNCEMENT_OPTION, 'anassa_flush_boot' );
add_action( 'add_option_' . ANASSA_ANNOUNCEMENT_OPTION, 'anassa_flush_boot' );

function anassa_announcement_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$a = anassa_announcement_get();
	$n = ANASSA_ANNOUNCEMENT_OPTION;

	$row = static function ( string $key, string $label, string $help = '' ) use ( $a, $n ) {
		printf(
			'<tr><th scope="row"><label for="a-%1$s">%2$s</label></th><td><input type="text" id="a-%1$s" name="%3$s[%1$s]" value="%4$s" class="large-text">%5$s</td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( $n ),
			esc_attr( (string) $a[ $key ] ),
			$help ? '<p class="description">' . esc_html( $help ) . '</p>' : ''
		);
	};
	?>
	<div class="wrap">
		<h1>Μπάρα ανακοίνωσης και newsletter</h1>
		<p>Η πράσινη μπάρα πάνω από το μενού. Δείχνει ένα μήνυμα και το κουμπί «Εγγραφή»: ο επισκέπτης γράφει το email του, τσεκάρει τη συναίνεση και η εγγραφή φτάνει στο μενού <strong>Αιτήματα</strong>. Αλλάξτε τα κείμενα και πατήστε «Αποθήκευση». Όποιος την έκλεισε με το «Χ» τη βλέπει ξανά όταν αλλάξει το μήνυμα.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'anassa_announcement_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Εμφάνιση</th>
					<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enabled]" value="1" <?php checked( ! empty( $a['enabled'] ) ); ?>> Να φαίνεται η μπάρα</label></td>
				</tr>
				<?php
				foreach ( anassa_announcement_fields() as $key => $meta ) {
					$row( $key, $meta[0], $meta[1] );
				}
				?>
			</table>
			<h2>English version (optional)</h2>
			<p>Shown when the visitor switches the site to English. If left empty, the built-in translation or the Greek text is shown.</p>
			<table class="form-table" role="presentation">
				<?php
				foreach ( anassa_announcement_fields() as $key => $meta ) {
					$row( $key . '_en', ucfirst( $key ) );
				}
				?>
			</table>
			<?php submit_button( 'Αποθήκευση' ); ?>
		</form>
	</div>
	<?php
}
