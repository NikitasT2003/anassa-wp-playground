<?php
/**
 * Οι φόρμες του site → wp-admin → Αιτήματα.
 *
 * Ίδιοι έλεγχοι με το `api/enquiry.ts`, και ένας ρητός κανόνας για όσα
 * διαφέρουν: ό,τι ο server αποφασίζει μόνος του (σφραγίδα συγκατάθεσης,
 * όρια, παγίδα) δεν το αφήνουμε στον browser.
 *
 *   · τα FORM_KEYS ταιριάζουν με το `FormKey` του `src/lib/submit.ts`
 *   · σώμα έως 16 KB, έως 25 πεδία, έως 2.000 χαρακτήρες το πεδίο
 *   · η παγίδα και ο ελάχιστος χρόνος (2 s) απαντούν 202 χωρίς να γραφτεί τίποτα
 *   · η συγκατάθεση απορρήτου είναι υποχρεωτική και η ΩΡΑ της μπαίνει εδώ
 *   · όριο: 5 αιτήματα / 10 λεπτά ανά IP και 120 / 10 λεπτά συνολικά
 *   · η IP δεν αποθηκεύεται ωμή, μόνο hash με μυστικό (ΓΚΠΔ)
 *
 * Δεν υπάρχει Turnstile εδώ· αν το ζητήσει ο πελάτης, μπαίνει στο ίδιο σημείο
 * που το έχει το `api/enquiry.ts`.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_ENQUIRY = 'anassa_enquiry';

const ANASSA_FORM_KEYS = array(
	'trip-enquiry'    => 'Εκδρομή',
	'groups-enquiry'  => 'Σύλλογοι / ομαδικά',
	'custom-enquiry'  => 'Σχεδιάζουμε μαζί',
	'gift-enquiry'    => 'Travel Gift Voucher',
	'contact-enquiry' => 'Επικοινωνία',
	'newsletter-signup' => 'Εγγραφή newsletter',
);

add_action(
	'init',
	static function () {
		register_post_type(
			ANASSA_ENQUIRY,
			array(
				'labels'          => array(
					'name'          => 'Αιτήματα',
					'singular_name' => 'Αίτημα',
					'menu_name'     => 'Αιτήματα',
					'all_items'     => 'Όλα τα αιτήματα',
					'edit_item'     => 'Αίτημα',
					'search_items'  => 'Αναζήτηση αιτημάτων',
					'not_found'     => 'Δεν υπάρχουν αιτήματα ακόμη',
				),
				'public'          => false,
				'show_ui'         => true,
				'menu_position'   => 6,
				'menu_icon'       => 'dashicons-email-alt',
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
			)
		);
	}
);

/* ---------------------------------------------------------------------------
   REST endpoint
   --------------------------------------------------------------------------- */
add_action(
	'rest_api_init',
	static function () {
		register_rest_route(
			'anassa/v1',
			'/enquiry',
			array(
				'methods'             => 'POST',
				'callback'            => 'anassa_handle_enquiry',
				'permission_callback' => '__return_true',
			)
		);
	}
);

function anassa_clean_text( $raw, int $max ): string {
	if ( ! is_string( $raw ) ) {
		return '';
	}
	$raw = preg_replace( '/[\x00-\x1f\x7f]/u', '', $raw );
	return mb_substr( trim( (string) $raw ), 0, $max );
}

/** Δύο κανόνες, σταθερό παράθυρο, με transients (object cache αν υπάρχει). */
function anassa_rate_limit( string $bucket, int $limit, int $window ): array {
	$key   = 'anassa_rl_' . md5( $bucket );
	$state = get_transient( $key );
	if ( ! is_array( $state ) || $state['reset'] <= time() ) {
		$state = array( 'count' => 0, 'reset' => time() + $window );
	}
	++$state['count'];
	set_transient( $key, $state, max( 1, $state['reset'] - time() ) );
	return array(
		'allowed' => $state['count'] <= $limit,
		'retry'   => max( 1, $state['reset'] - time() ),
	);
}

function anassa_client_ip(): string {
	/* Πίσω από Cloudflare το `CF-Connecting-IP` είναι αξιόπιστο· αλλιώς μόνο το
	   REMOTE_ADDR. Το X-Forwarded-For το γράφει ο πελάτης και δεν το εμπιστευόμαστε. */
	$cf = isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? trim( (string) $_SERVER['HTTP_CF_CONNECTING_IP'] ) : '';
	if ( '' !== $cf && filter_var( $cf, FILTER_VALIDATE_IP ) && ! empty( $_SERVER['HTTP_CF_RAY'] ) ) {
		return $cf;
	}
	return isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : 'unknown';
}

function anassa_rest_error( string $message, int $status, array $headers = array() ): WP_REST_Response {
	$res = new WP_REST_Response( array( 'error' => $message ), $status );
	$res->header( 'Cache-Control', 'no-store' );
	foreach ( $headers as $name => $value ) {
		$res->header( $name, $value );
	}
	return $res;
}

function anassa_handle_enquiry( WP_REST_Request $request ): WP_REST_Response {
	if ( ! str_contains( (string) $request->get_header( 'content-type' ), 'application/json' ) ) {
		return anassa_rest_error( 'Expected application/json.', 415 );
	}
	$raw = $request->get_body();
	if ( strlen( $raw ) > 16384 ) {
		return anassa_rest_error( 'Το αίτημα είναι πολύ μεγάλο.', 413 );
	}
	$body = json_decode( $raw, true );
	if ( ! is_array( $body ) ) {
		return anassa_rest_error( 'Μη έγκυρο JSON.', 400 );
	}

	/* Το όριο ελέγχεται ΠΡΙΝ από κάθε άλλη δουλειά. */
	$pepper = wp_salt( 'auth' );
	$ip     = hash( 'sha256', $pepper . ':' . anassa_client_ip() );
	$per_ip = anassa_rate_limit( 'ip:' . $ip, 5, 600 );
	$all    = anassa_rate_limit( 'all', 120, 600 );
	if ( ! $per_ip['allowed'] || ! $all['allowed'] ) {
		$retry = max( $per_ip['retry'], $all['retry'] );
		return anassa_rest_error( 'Έχουν σταλεί πολλά αιτήματα. Δοκιμάστε ξανά σε λίγα λεπτά ή τηλεφωνήστε μας.', 429, array( 'Retry-After' => (string) $retry ) );
	}

	/* Παγίδα και χρόνος: 202, χωρίς εγγραφή. */
	$trap    = anassa_clean_text( $body['trap'] ?? '', 100 );
	$elapsed = isset( $body['elapsedMs'] ) && is_numeric( $body['elapsedMs'] ) ? (float) $body['elapsedMs'] : null;
	if ( '' !== $trap || ( null !== $elapsed && $elapsed < 2000 ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 202 );
	}

	$form_key = anassa_clean_text( $body['formKey'] ?? '', 40 );
	if ( ! array_key_exists( $form_key, ANASSA_FORM_KEYS ) ) {
		return anassa_rest_error( 'Άγνωστη φόρμα.', 400 );
	}

	$raw_fields = $body['fields'] ?? null;
	if ( ! is_array( $raw_fields ) || array_is_list( $raw_fields ) ) {
		return anassa_rest_error( 'Λείπουν τα στοιχεία της φόρμας.', 400 );
	}
	$fields = array();
	foreach ( array_slice( $raw_fields, 0, 25, true ) as $label => $value ) {
		$clean = anassa_clean_text( is_numeric( $value ) ? (string) $value : $value, 2000 );
		if ( '' !== $clean ) {
			$fields[ anassa_clean_text( (string) $label, 120 ) ] = $clean;
		}
	}
	if ( ! $fields ) {
		return anassa_rest_error( 'Η φόρμα ήρθε κενή.', 400 );
	}

	$consents = is_array( $body['consents'] ?? null ) ? $body['consents'] : array();
	if ( empty( $consents['privacy'] ) ) {
		return anassa_rest_error( 'Χρειαζόμαστε τη συγκατάθεση για την πολιτική απορρήτου.', 400 );
	}
	$now       = gmdate( 'c' );
	$marketing = ! empty( $consents['marketing'] );

	/* Ο τίτλος της εγγραφής: φόρμα + όνομα, αν υπάρχει πεδίο με «όνομα». */
	$who = '';
	foreach ( $fields as $label => $value ) {
		/* Χωρίς τόνους, γιατί το πεδίο λέγεται «Ονοματεπώνυμο» (κεφαλαίο, τονισμένο
		   αλλιώς από το «όνομα»). */
		if ( false !== mb_stripos( remove_accents( (string) $label ), 'ονομα' ) ) {
			$who = $value;
			break;
		}
	}
	$title = ANASSA_FORM_KEYS[ $form_key ] . ( '' !== $who ? ': ' . $who : '' );

	$id = wp_insert_post(
		array(
			'post_type'   => ANASSA_ENQUIRY,
			'post_status' => 'publish',
			'post_title'  => $title,
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		return anassa_rest_error( 'Δεν καταφέραμε να καταχωρήσουμε το αίτημα.', 502 );
	}
	update_post_meta( $id, '_anassa_form_key', $form_key );
	update_post_meta( $id, '_anassa_fields', $fields );
	update_post_meta( $id, '_anassa_consent_privacy', $now );
	update_post_meta( $id, '_anassa_consent_marketing', $marketing ? $now : '' );

	anassa_notify_office( $title, $fields, $marketing );

	$res = new WP_REST_Response( array( 'ok' => true, 'checks' => array( 'turnstile' => 'disabled' ) ), 201 );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/** Email στο γραφείο. Αποτυχία email δεν χάνει το αίτημα: μένει στο wp-admin. */
function anassa_notify_office( string $title, array $fields, bool $marketing ): void {
	$to = apply_filters( 'anassa_enquiry_to', get_option( 'admin_email' ) );
	if ( ! $to ) {
		return;
	}
	$lines = array();
	foreach ( $fields as $label => $value ) {
		$lines[] = $label . ': ' . $value;
	}
	$lines[] = '';
	$lines[] = $marketing ? 'Δέχεται ενημερώσεις για προσφορές.' : 'Δεν επιθυμεί ενημερώσεις για προσφορές.';
	$lines[] = '';
	$lines[] = 'Όλα τα αιτήματα: ' . admin_url( 'edit.php?post_type=' . ANASSA_ENQUIRY );
	wp_mail( $to, 'Νέο αίτημα: ' . $title, implode( "\n", $lines ) );
}

/* ---------------------------------------------------------------------------
   Η οθόνη του αιτήματος στο wp-admin: μόνο ανάγνωση.
   --------------------------------------------------------------------------- */
add_action(
	'add_meta_boxes',
	static function () {
		add_meta_box(
			'anassa_enquiry_view',
			'Τι έστειλε ο επισκέπτης',
			static function ( WP_Post $post ) {
				$fields = get_post_meta( $post->ID, '_anassa_fields', true );
				echo '<table class="widefat striped"><tbody>';
				foreach ( is_array( $fields ) ? $fields : array() as $label => $value ) {
					printf( '<tr><th style="width:30%%">%s</th><td>%s</td></tr>', esc_html( (string) $label ), nl2br( esc_html( (string) $value ) ) );
				}
				echo '</tbody></table>';
				$privacy   = (string) get_post_meta( $post->ID, '_anassa_consent_privacy', true );
				$marketing = (string) get_post_meta( $post->ID, '_anassa_consent_marketing', true );
				printf(
					'<p><strong>Συγκατάθεση απορρήτου:</strong> %s<br><strong>Ενημερώσεις για προσφορές:</strong> %s</p>',
					esc_html( $privacy ),
					esc_html( '' !== $marketing ? $marketing : 'Όχι' )
				);
			},
			ANASSA_ENQUIRY,
			'normal',
			'high'
		);
	}
);

add_filter(
	'manage_' . ANASSA_ENQUIRY . '_posts_columns',
	static function ( array $columns ): array {
		return array(
			'cb'          => $columns['cb'],
			'title'       => 'Αίτημα',
			'anassa_form' => 'Φόρμα',
			'date'        => 'Ημερομηνία',
		);
	}
);

add_action(
	'manage_' . ANASSA_ENQUIRY . '_posts_custom_column',
	static function ( string $column, int $post_id ) {
		if ( 'anassa_form' === $column ) {
			$key = (string) get_post_meta( $post_id, '_anassa_form_key', true );
			echo esc_html( ANASSA_FORM_KEYS[ $key ] ?? $key );
		}
	},
	10,
	2
);
