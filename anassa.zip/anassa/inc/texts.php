<?php
/**
 * Τα σταθερά κείμενα της αρχικής και του υποσελίδου, επεξεργάσιμα από το
 * wp-admin: «Ρυθμίσεις → Κείμενα αρχικής και υποσελίδου».
 *
 * Το μητρώο παρακάτω είναι ο κατάλογος των πεδίων. Τα κλειδιά και τα ελληνικά
 * προεπιλεγμένα κείμενα ΠΡΕΠΕΙ να είναι ίδια με όσα περνά το React στο `st()`
 * (`src/lib/siteText.ts`)· αν αλλάξετε το ένα, αλλάξτε και το άλλο.
 *
 * Στο React περνούν ΜΟΝΟ τα πεδία που ο πελάτης άλλαξε. Ό,τι μένει στην
 * προεπιλογή δεν αποθηκεύεται και ακολουθεί το site (και τη μετάφρασή του).
 * Αγγλικό πεδίο κενό = η ενσωματωμένη αγγλική μετάφραση, αλλιώς το ελληνικό.
 */

defined( 'ABSPATH' ) || exit;

const ANASSA_TEXTS_OPTION = 'anassa_texts';

/** key => [ ομάδα, ετικέτα πεδίου, προεπιλεγμένο ελληνικό κείμενο, πολλές γραμμές; ] */
function anassa_texts_registry(): array {
	return array(
		'home.hero.title'       => array( 'Αρχική: εισαγωγή (πάνω ζώνη)', 'Μεγάλος τίτλος', 'Εκδρομές με άποψη', false ),
		'home.hero.cta1'        => array( 'Αρχική: εισαγωγή (πάνω ζώνη)', 'Πρώτο κουμπί', 'Δείτε τις εκδρομές', false ),
		'home.hero.cta2'        => array( 'Αρχική: εισαγωγή (πάνω ζώνη)', 'Δεύτερο κουμπί', 'Σχεδιάζουμε Μαζί', false ),

		'home.greece.title'     => array( 'Αρχική: εκδρομές Ελλάδας', 'Τίτλος ζώνης', 'Εκδρομές Ελλάδας', false ),
		'home.greece.sub'       => array( 'Αρχική: εκδρομές Ελλάδας', 'Υπότιτλος', 'Μοναδικοί προορισμοί, αξέχαστες εμπειρίες', false ),
		'home.greece.more'      => array( 'Αρχική: εκδρομές Ελλάδας', 'Κουμπί κάτω από τις κάρτες', 'Όλες οι εκδρομές Ελλάδας', false ),

		'home.abroad.title'     => array( 'Αρχική: εκδρομές εξωτερικού', 'Τίτλος ζώνης', 'Εκδρομές Εξωτερικού', false ),
		'home.abroad.sub'       => array( 'Αρχική: εκδρομές εξωτερικού', 'Υπότιτλος', 'Οδικώς και αεροπορικώς, με αρχηγό-συνοδό', false ),
		'home.abroad.more'      => array( 'Αρχική: εκδρομές εξωτερικού', 'Κουμπί κάτω από τις κάρτες', 'Όλες οι εκδρομές εξωτερικού', false ),

		'home.about.title'      => array( 'Αρχική: ζώνη «Η ιστορία μας»', 'Τίτλος', 'Η ιστορία μας, το ταξίδι μας.', false ),
		'home.about.text'       => array( 'Αρχική: ζώνη «Η ιστορία μας»', 'Κείμενο', 'Από το 2002 μέχρι σήμερα, μια διαδρομή γεμάτη ταξίδια, εμπειρίες και ανθρώπους που μας εμπιστεύτηκαν. Γνώρισε την ιστορία πίσω από το ANASSA HOLIDAYS και ανακάλυψε πώς η παράδοση συναντά τη νέα εποχή των ταξιδιών.', true ),
		'home.about.cta'        => array( 'Αρχική: ζώνη «Η ιστορία μας»', 'Κουμπί', 'Ανακάλυψε την ιστορία μας', false ),

		'footer.tagline'        => array( 'Υποσέλιδο: γενικά', 'Σύντομη περιγραφή κάτω από το λογότυπο', 'Οργανωμένες οδικές και αεροπορικές εκδρομές στην Ελλάδα και το εξωτερικό, με ιδιόκτητα λεωφορεία.', true ),
		'footer.col.trips'      => array( 'Υποσέλιδο: γενικά', 'Επικεφαλίδα στήλης «Ταξίδια»', 'Ταξίδια', false ),
		'footer.col.company'    => array( 'Υποσέλιδο: γενικά', 'Επικεφαλίδα στήλης «Η εταιρεία»', 'Η εταιρεία', false ),
		'footer.col.offices'    => array( 'Υποσέλιδο: γενικά', 'Επικεφαλίδα στήλης «Γραφεία»', 'Γραφεία', false ),
		'footer.eot'            => array( 'Υποσέλιδο: γενικά', 'Ετικέτα πριν τον αριθμό ΕΟΤ', 'Αριθμός Σήματος ΕΟΤ:', false ),

		'newsletter.title'      => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Τίτλος', 'Εγγραφή στο Newsletter', false ),
		'newsletter.intro'      => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Σύντομη πρόταση', 'Αφήστε το email σας και θα σας ενημερώνουμε για νέες εκδρομές και προσφορές.', true ),
		'newsletter.button'     => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Κουμπί εγγραφής', 'Εγγραφή', false ),
		'newsletter.consent'    => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Κείμενο συναίνεσης (GDPR)', 'Συναινώ στην συλλογή των στοιχείων μου από την ιστοσελίδα anassatravel.gr έτσι ώστε να είναι δυνατή η προσθήκη της διεύθυνσης E-mail μου στην λίστα παραληπτών newsletters', true ),
		'newsletter.privacy'    => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Σύνδεσμος πολιτικής απορρήτου', 'Διαβάστε την Πολιτική Απορρήτου', false ),
		'newsletter.done.title' => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Μετά την εγγραφή: τίτλος', 'Η εγγραφή σας καταχωρήθηκε', false ),
		'newsletter.done.text'  => array( 'Υποσέλιδο: εγγραφή στο newsletter', 'Μετά την εγγραφή: κείμενο', 'Σας ευχαριστούμε. Θα λαμβάνετε τα newsletters μας στη διεύθυνση που δηλώσατε.', true ),
	);
}

function anassa_texts_get(): array {
	$saved = get_option( ANASSA_TEXTS_OPTION );
	return is_array( $saved ) ? $saved : array();
}

/** Ό,τι περνά στο React: μόνο τα πεδία που άλλαξε ο πελάτης, ως {key:{el,en}}. */
function anassa_texts_payload(): array {
	$saved = anassa_texts_get();
	$out   = array();
	foreach ( anassa_texts_registry() as $key => $def ) {
		$row = isset( $saved[ $key ] ) && is_array( $saved[ $key ] ) ? $saved[ $key ] : array();
		$el  = isset( $row['el'] ) ? trim( (string) $row['el'] ) : '';
		$en  = isset( $row['en'] ) ? trim( (string) $row['en'] ) : '';
		if ( $el === $def[2] ) {
			$el = '';
		}
		if ( '' !== $el || '' !== $en ) {
			$out[ $key ] = array(
				'el' => $el,
				'en' => $en,
			);
		}
	}
	return $out;
}

function anassa_texts_sanitize( $in ): array {
	$in  = is_array( $in ) ? $in : array();
	$out = array();
	foreach ( anassa_texts_registry() as $key => $def ) {
		$row   = isset( $in[ $key ] ) && is_array( $in[ $key ] ) ? $in[ $key ] : array();
		$clean = $def[3] ? 'sanitize_textarea_field' : 'sanitize_text_field';
		$el    = isset( $row['el'] ) ? trim( $clean( wp_unslash( $row['el'] ) ) ) : '';
		$en    = isset( $row['en'] ) ? trim( $clean( wp_unslash( $row['en'] ) ) ) : '';
		if ( $el === $def[2] ) {
			$el = '';
		}
		if ( '' !== $el || '' !== $en ) {
			$out[ $key ] = array(
				'el' => $el,
				'en' => $en,
			);
		}
	}
	return $out;
}

add_action(
	'admin_init',
	static function () {
		register_setting(
			'anassa_texts_group',
			ANASSA_TEXTS_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => 'anassa_texts_sanitize',
				'default'           => array(),
			)
		);
	}
);

add_action(
	'admin_menu',
	static function () {
		add_options_page( 'Κείμενα αρχικής και υποσελίδου', 'Κείμενα αρχικής και υποσελίδου', 'manage_options', 'anassa-texts', 'anassa_texts_page' );
	}
);

/* Η αποθήκευση καθαρίζει την προσωρινή μνήμη των δεδομένων της σελίδας. */
add_action( 'update_option_' . ANASSA_TEXTS_OPTION, 'anassa_flush_boot' );
add_action( 'add_option_' . ANASSA_TEXTS_OPTION, 'anassa_flush_boot' );

function anassa_texts_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$saved = anassa_texts_get();
	$n     = ANASSA_TEXTS_OPTION;
	$group = '';
	?>
	<div class="wrap">
		<h1>Κείμενα αρχικής και υποσελίδου</h1>
		<p>Τα σταθερά κείμενα της αρχικής σελίδας και του υποσελίδου. Το ελληνικό πεδίο δείχνει το τρέχον κείμενο· αλλάξτε το και πατήστε «Αποθήκευση». Αν το αφήσετε όπως είναι, το site συνεχίζει να χρησιμοποιεί το αρχικό. Το αγγλικό πεδίο, αν μείνει κενό, δείχνει την ενσωματωμένη αγγλική μετάφραση.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'anassa_texts_group' ); ?>
			<?php
			foreach ( anassa_texts_registry() as $key => $def ) {
				if ( $def[0] !== $group ) {
					if ( '' !== $group ) {
						echo '</table>';
					}
					$group = $def[0];
					echo '<h2>' . esc_html( $group ) . '</h2><table class="form-table" role="presentation">';
				}
				$row = isset( $saved[ $key ] ) && is_array( $saved[ $key ] ) ? $saved[ $key ] : array();
				$el  = isset( $row['el'] ) && '' !== $row['el'] ? (string) $row['el'] : $def[2];
				$en  = isset( $row['en'] ) ? (string) $row['en'] : '';
				$id  = 'tx-' . sanitize_html_class( str_replace( '.', '-', $key ) );
				echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '-el">' . esc_html( $def[1] ) . '</label></th><td>';
				foreach ( array(
					'el' => array( 'Ελληνικά', $el ),
					'en' => array( 'English (optional)', $en ),
				) as $lang => $f ) {
					$name = $n . '[' . $key . '][' . $lang . ']';
					echo '<p style="margin:0 0 4px"><span class="description">' . esc_html( $f[0] ) . '</span></p>';
					if ( $def[3] ) {
						printf(
							'<textarea id="%1$s-%2$s" name="%3$s" rows="3" class="large-text" style="margin-bottom:10px">%4$s</textarea>',
							esc_attr( $id ),
							esc_attr( $lang ),
							esc_attr( $name ),
							esc_textarea( $f[1] )
						);
					} else {
						printf(
							'<input type="text" id="%1$s-%2$s" name="%3$s" value="%4$s" class="large-text" style="margin-bottom:10px">',
							esc_attr( $id ),
							esc_attr( $lang ),
							esc_attr( $name ),
							esc_attr( $f[1] )
						);
					}
				}
				echo '</td></tr>';
			}
			if ( '' !== $group ) {
				echo '</table>';
			}
			submit_button( 'Αποθήκευση' );
			?>
		</form>
	</div>
	<?php
}
